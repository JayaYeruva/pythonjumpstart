__author__ = 'ravi'
'''
doc string
'''

s = '''
    1
   2 2
  3 {} 3
   4 4
    5
'''.format('x')
print '-' * 10
print s.strip('\n')
print '-' * 10


