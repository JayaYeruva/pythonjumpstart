__author__ = 'ravi'
from random import randint
guess = randint(1, 1000)
i = 1

while i <= 10:
    value = input("Chance :{}\nEnter the value :".format(i))

    if value == guess:
        print "you won :) !!!!!!!!!!!!!!"
        break

    print "{} is greater".format(value) if value > guess  \
        else "{} is lesser".format(value)

    i += 1

else:
    print "You lost :(................"
    exit(1)
