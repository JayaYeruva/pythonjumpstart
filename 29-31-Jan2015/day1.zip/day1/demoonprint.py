__author__ = 'ravi'

print 'kim',
print 'abe',
print 'tim',
print 'jim',
print "nelson",
print 'amanda'

