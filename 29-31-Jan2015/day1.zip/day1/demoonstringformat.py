__author__ = 'ravi'

__author__ = 'ravi'

from math import pi

radius = input('Enter the radius :')

area = pi * (radius ** 2)

#result = "radius : {0}\narea : {1:.3f}".format(radius, area)
result = "radius : {}\narea : {:.3f}".format(radius, area)
print result

