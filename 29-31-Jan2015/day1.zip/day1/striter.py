__author__ = 'ravi'

s = 'pypi'

for item in s:
    print "{} : {}".format(item, ord(item))
    \print '-' * 5

print item