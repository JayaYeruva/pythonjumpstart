from __future__ import print_function
__author__ = 'ravi'


print('amanda', end="|")
print('kimberly', end="|")
print('nancy', end="|")
print('rose')
print(help(print))

