__author__ = 'ravi'

s = 'this\tis\ta\ndemo\tstring'
en_s =  s.encode('string-escape')

print en_s.decode('string-escape')
#s = r'this\tis\ta\ndemo\tstring'  #raw string
#print s

#r'\tabbing'