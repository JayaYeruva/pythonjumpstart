__author__ = 'ravi'


l = [1, 'pypi', 35000.12, 'allen', 'paul']



l[-1] = 'bruce almighty'
l[0] = 'one'
print l
print '---'

for item in l:
    del l[2]
    print l
    print '---'
    print item


