__author__ = 'ravi'
# -*-coding:utf-8-*-

s = ur''
print s
