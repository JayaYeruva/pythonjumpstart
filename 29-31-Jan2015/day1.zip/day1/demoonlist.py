__author__ = 'ravi'

l = []

print l
print len(l)
print type(l)
