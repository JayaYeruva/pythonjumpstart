__author__ = 'ravi'

s = 'perlandpython'
i = 1
for char in s:
    if i%2 :
        print char * i  #char.__mul__(i)
    i += 1
