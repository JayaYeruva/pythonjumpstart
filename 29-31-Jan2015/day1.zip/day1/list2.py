__author__ = 'ravi'


l = [1, 'pypi', 35000.12, 'allen', 'paul']

print l
print len(l)
print type(l)

