__author__ = 'ravi'

# comment
# for a demo of input()
value = input('Enter the value :')

'''
print value
print type(value)
'''

