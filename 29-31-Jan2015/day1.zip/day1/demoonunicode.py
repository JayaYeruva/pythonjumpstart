# -*- coding: utf-8 -*-
__author__ = 'ravi'



s = u'ಜಯಕಿರಣ - ‎ಕನ್ನಡಪ್ರಭ - ‎ವೆಬ್ ದುನಿಯ'
print s
