__author__ = 'ravi'

i = 1

while i <= 5:
    print i
    #if i == 3:
    #    break
    i += 1
else:
    print "else block of while"


