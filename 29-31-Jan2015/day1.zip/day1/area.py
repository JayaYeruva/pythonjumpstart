__author__ = 'ravi'

from math import pi

radius = input('Enter the radius :')

area = pi * (radius ** 2)

result = "radius : %f\narea : %.3f" % (radius, area)

print result.upper()
