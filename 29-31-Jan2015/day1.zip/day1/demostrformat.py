__author__ = 'ravi'

name = 'pam'
gender = 'female'
age = 4

print "|{}|{}|{}|".format(name, age, gender)
print "|{:>10}|{:>8}|{:>15}|".format(name, age, gender)
print "|{:>10}|{:>8}|{:>15}|".format(name, age, gender)
print "|{:<10}|{:<8}|{:<15}|".format(name, age, gender)
print "|{:<10}|{:<8}|{:<15}|".format(name, age, gender)
print "|{:^10}|{:^8}|{:^15}|".format(name, age, gender)
print "|{:^10}|{:^8}|{:^15}|".format(name, age, gender)
print "|{:10}|{:8}|{:15}|".format(name, age, gender)
