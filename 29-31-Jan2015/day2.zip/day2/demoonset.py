from pprint import pprint

users = {l.split(':')[0] for l in open('/etc/passwd')}
group  = {l.split(':')[0] for l in open('/etc/group')}

pprint(users.intersection(group))

pprint(users.difference(group))

pprint(group - users)
