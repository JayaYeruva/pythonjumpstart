__author__ = 'ravi'

s = 'root:x:0:0:root:/root:/bin/bash'
l =  s.split(':')

print s.split(':')[0]


print '|'.join(l)