__author__ = 'ravi'

user_list = []

with open('/etc/passwd') as fp:
    for line in fp:
        user_list.append(line.split(':')[0].title())

#from pprint import pprint
#pprint(user_list)

i = 1
for name in sorted(user_list):
    print "{:>6}  {}".format(i, name)
    i += 1

