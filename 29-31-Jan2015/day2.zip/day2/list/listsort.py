__author__ = 'ravi'
from random import shuffle

items = ['eva', 'pat', 'nat', 'kate', 'kim', 'anna', 4, 1, 6 ,7, 1.1, 5]
shuffle(items)

#items.sort(reverse=True)

for item in sorted(items, reverse=True):
    print item
#items.reverse()

#print items

