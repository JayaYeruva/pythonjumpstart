__author__ = 'ravi'

l = range(1, 6)
temp = []

for i in l:
    temp.append(i ** i)

print temp

#list comp.
res = [i **i for i in range(1, 6)]
print res