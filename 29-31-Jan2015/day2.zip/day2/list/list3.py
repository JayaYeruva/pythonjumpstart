
l = ['root', 'x', 0, 0, 'root', '/root', '/bin/bash']
l.append('/etc/passwd')
print l
print

value = l.pop(1)
print value
print l