__author__ = 'ravi'
file_name = 'userlist.dat'
user_list = []

with open('/etc/passwd') as fp:
    for line in fp:
        user_list.append(line.split(':')[0].title())

with open(file_name, 'w') as fw:
    for i, name in enumerate(sorted(user_list), 1):
        result = "{:>6}  {}".format(i, name)
        print result
        fw.write(result+"\n")

