__author__ = 'ravi'
from pprint import pprint

# ul = sorted([l.split(':')[0].upper() for l in open('/etc/passwd')])

ul = sorted([l.split(':')[0].lstrip('_').upper()
             for l in open('/etc/passwd') if not l.startswith('#')])


pprint(ul)
