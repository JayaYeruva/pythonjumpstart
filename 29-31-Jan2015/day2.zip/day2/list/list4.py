l = ['root', 'x', 0, 0, 'root', '/root', '/bin/bash']

'''
l.insert(0, 'administrator')
print l
'''

print l[:-2]

for i in l[:-2]:
    print i



