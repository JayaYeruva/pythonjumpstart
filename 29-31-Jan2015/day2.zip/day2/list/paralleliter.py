__author__ = 'ravi'

names = ['allen', 'paul', 'brown', 'hellen']
age = [3, 2, 4, 2]
gender = ['male', 'male', 'male', 'female']

#from pprint import pprint
#pprint(zip(names, age, gender))

for n, a, g in zip(names, age, gender):
    print "{:>22}  {:>5}  {:>12}".format(n, a, g)
