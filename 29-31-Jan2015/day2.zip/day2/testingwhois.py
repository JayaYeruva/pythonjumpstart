import whois
domain = whois.query('google.com')

#print domain
