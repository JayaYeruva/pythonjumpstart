from pprint import pprint

l = [l.rstrip('\n').split(':') for l in open('/etc/passwd')]

pprint(l)
