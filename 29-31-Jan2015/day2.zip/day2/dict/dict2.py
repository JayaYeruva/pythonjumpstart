__author__ = 'ravi'

info = {'hostname': 'ws1',
        'domain': 'rootcap.in', 'ipaddr': '122.1.1.1',
        'apps': 'web server', ''}

print len(info)
print type(info)
print info