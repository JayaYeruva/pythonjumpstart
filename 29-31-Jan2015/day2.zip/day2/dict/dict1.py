__author__ = 'ravi'

info = {}

print len(info)
print type(info)
print info
