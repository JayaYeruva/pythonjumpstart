

l = range(2, 6)

res = map(lambda value: value + 2, l)
print l
print res

print map(bin, l)
print map(ord, 'ABCD')

