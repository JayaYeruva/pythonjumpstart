__author__ = 'ravi'

info = {'hostname': 'ws1',
        'domain': 'rootcap.in', 'ipaddr': '122.1.1.1',
        'apps': 'web server'}

value = info.pop('apps')

del info['ipaddr']

print value
print info

