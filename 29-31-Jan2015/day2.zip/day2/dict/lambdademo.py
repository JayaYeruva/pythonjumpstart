

# lambda args, args: functionality

sum = lambda x, y: x + y

#print sum(10, 11)
#print sum('peter', 'pan')

power = lambda x, n=0: x **n

print  power(3, 2)
print power(5)


