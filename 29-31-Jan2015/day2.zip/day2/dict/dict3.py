__author__ = 'ravi'

info = {'hostname': 'ws1',
        'domain': 'rootcap.in', 'ipaddr': '122.1.1.1',
        'apps': 'web server'}

info.setdefault('arch', 'x86_64')

if info.has_key('domain'):
    info['domain'] = 'testit.in'

print info['arch']
print info['desc']


