from pprint import pprint

wc = {}

for line in open('sample.txt'):
    for word in line.rstrip().split(' '):
        wc[word] = wc.get(word, 0) + 1

i = 1
for word in sorted(wc, cmp=lambda key1, key2: cmp(wc[key2], wc[key1])):
    print "{} : {}\t".format(word, wc[word]),
    if i%4==0:
        print
    i += 1

# pprint(wc)


