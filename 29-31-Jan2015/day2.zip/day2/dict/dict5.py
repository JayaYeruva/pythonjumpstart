__author__ = 'ravi'

info = {'hostname': 'ws1',
        'domain': 'rootcap.in', 'ipaddr': '122.1.1.1',
        'apps': 'web server'}


print info['hostname']
print info['domain']
print info.get('ipaddr')
print info.get('application')
print info.get('application', 'unknown key')