__author__ = 'ravi'

info = {'hostname': 'ws1',
        'domain': 'rootcap.in', 'ipaddr': '122.1.1.1',
        'apps': 'web server', 'desc': 'test server'}

for k in info:
    print "[{}] -> {}".format(k, info[k])

print; print

for k in sorted(info):
    print "[{}] -> {}".format(k, info[k])