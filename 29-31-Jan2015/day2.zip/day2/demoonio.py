__author__ = 'ravi'

import sys
temp = sys.stdout

with open('tempfile', 'w') as fw:
    sys.stdout = fw

    print "allen"
    print "pretty python"
    print "its damn fun"

sys.stdout = temp

print "guess, where it goes !!!!!!!!!!!"


