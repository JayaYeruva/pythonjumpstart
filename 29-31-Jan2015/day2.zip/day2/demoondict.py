from pprint import pprint

users = {l.split(':')[0]: l.rstrip().split(':')[1:] for l 
                        in open('/etc/passwd')}

for user in users:
    print "{}".format(user)
    for item in users[user]:
        print "\t{}".format(item)
    print 
    
        
'''
print users['root'][0]
print users['root'][1]
print users['root'][2]
'''
