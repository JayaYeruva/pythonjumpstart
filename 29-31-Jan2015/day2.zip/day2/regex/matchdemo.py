import re

pattern = 'PythoN'
s = 'the python and the perl script'

m = re.match(pattern, s, re.I)

if m:
    print "we got a match :)"
else:
    print "fails to match :("
    
