import re

pattern = 'PythoN'
s = 'the python and the perl script'

m = re.search(pattern, s, re.I)

if m:
    print "we got a match :)"
    print m.group()
    print"{}|".format( s[:m.start()])
    print "|{}".format(s[m.end():])
    print m.span()
else:
    print "fails to match :("
    
