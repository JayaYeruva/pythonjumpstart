import fileinput
import sys
import re

pattern = sys.argv.pop(1)
#print sys.argv; exit(1)

for l in fileinput.input():
    if re.search(pattern, l, re.IGNORECASE):
        print l.rstrip('\n')
