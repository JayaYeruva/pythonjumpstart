import re

s = 'the perl and the perl and the perl scirpting'

c = re.compile('(P)(e)(r)(l)', re.I)

for m in c.finditer(s):
    print m.group()
    print m.groups()
    print m.span()
    print


