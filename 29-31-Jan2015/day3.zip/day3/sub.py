import re

s = 'this is a sample string'

print re.sub('([AEIOU])',r'[\1]',s, flags=re.I )
