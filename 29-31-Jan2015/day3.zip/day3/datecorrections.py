import fileinput
import re
import shutil

def fix_date(pattern, sub_str):
    c = re.compile(pattern, flags=re.I)

    for line in fileinput.input(inplace=True, backup='.bak'):
        print c.sub(sub_str, line.rstrip('\n'))
        

pattern = r'([A-Z][a-z]{2})\ (0[1-9]|[12][0-9]|3[01])\ (\d\d:\d\d:\d\d)'
sub_str = r'[\3] \2 \1'

fix_date(pattern, sub_str)

temp = 'tempfile'
shutil.move(fileinput.filename(), temp)
shutil.move(fileinput.filename()+'.bak', fileinput.filename())
shutil.move(temp, fileinput.filename()+'.bak')





