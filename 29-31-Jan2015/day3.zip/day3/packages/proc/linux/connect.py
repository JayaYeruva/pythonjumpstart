
def getconnect():
    print "connection driver for the linux"
