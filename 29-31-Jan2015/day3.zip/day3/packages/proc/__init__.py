from linux import getconnect

