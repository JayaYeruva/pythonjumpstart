'''testmod
a sample python module
author : class
'''
author = 'jaya'
version = '0.0.1 beta'

def power(x, n=0):
    '''power(x, n)
       raises x to the power of n
    '''    
    return x **n

def raiseme(n):
    '''raiseme(n)
       yet another function
    '''
    return n**2 if n>5 else n**3

class Person(object):
    '''Person
    a dummy python class
    '''

    def __init__(self, first_name, last_name, age, gender):
        '''__init__
        constructor
        '''
        self.first_name = first_name
        self.last_name = last_name
        self.age = age
        self.gender = gender 

    def get_info(self):
        '''get_info()
        get the obeject content
        '''
        print "first name : {}".format(self.first_name)    
        print "last name : {}".format(self.last_name)    
        print "age : {}".format(self.age)    
        print "gender : {}".format(self.gender)    

if __name__ == '__main__':
    print __name__
    p = Person('larry', 'wall', 4, 'male')
    p.get_info()        
    print power(3, 2)
    print raiseme(4)
    print author
