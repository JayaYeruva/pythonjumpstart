import testmod
#import sys
#from pprint import pprint 

#pprint(sys.path); exit(1)
print testmod.raiseme(5)
print testmod.version
