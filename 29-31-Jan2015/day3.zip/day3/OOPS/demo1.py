
class Demo(object):
    def __init__(self, data):
        self.data = data
        print "constructor : {}".format(self)
    
    def get_data(self):
        return self.data

    def __del__(self):
        print "destructor : {}".format(self)
        
d = Demo(1000)
print d.get_data()

            
