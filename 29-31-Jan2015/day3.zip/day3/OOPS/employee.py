from person import Person

class Employee(Person):

    def __init__(self, eid, first_name, last_name, age, gender, desg):
        self.eid = eid
        self.desg = desg

        super(Employee, self).__init__(first_name, \
                last_name, age, gender) #invoke base class constructor

    def get_info(self):
        print "employee id : {}".format(self.eid)
        super(Employee, self).get_info()
        print "designation : {}".format(self.desg)            

if __name__ == '__main__':
    e =  Employee('e1001', 'guido', 'rossum', 2, 'male', 'clerk')
    e.get_info()    
