
class Box(object):
    def __init__(self, side):
        self.side = side 

    def __mul__(self, n):
        return Box(self.side * n)    

    def __add__(self, other):
        return Box(self.side + other.side)    

    #def __str__(self):
    #    return "<{} side={}>".format(self.__class__.__name__, self.side)    


if __name__ == '__main__':
    b1 = Box(10)
    b2 = Box(11)
    b3 = b1 + b2   #  b1.__add__(b2)
    print b3 * 3 
