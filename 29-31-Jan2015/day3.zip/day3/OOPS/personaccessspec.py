class Person(object):
    def __init__(self, first_name, last_name, age, gender):
        self.__first_name = first_name
        self.__last_name = last_name
        self.age = age
        self.gender = gender 

    def wrap(self):
        self.__get_info()    

    def __get_info(self):
        print "first name : {}".format(self.__first_name)    
        print "last name : {}".format(self.__last_name)    
        print "age : {}".format(self.age)    
        print "gender : {}".format(self.gender)    

if __name__ == '__main__':
    print __name__
    p = Person('larry', 'wall', 4, 'male')
    print p.wrap()
