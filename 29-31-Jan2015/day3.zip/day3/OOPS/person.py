class Person(object):
    def __init__(self, first_name, last_name, age, gender):
        self.first_name = first_name
        self.last_name = last_name
        self.age = age
        self.gender = gender 

    def get_info(self):
        print "first name : {}".format(self.first_name)    
        print "last name : {}".format(self.last_name)    
        print "age : {}".format(self.age)    
        print "gender : {}".format(self.gender)    

if __name__ == '__main__':
    print __name__
    p = Person('larry', 'wall', 4, 'male')
    p.get_info()        
