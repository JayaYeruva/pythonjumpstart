import fileinput
import re

def matchit():
    c = re.compile('\[(\d+\.\d+)\]')
    for l in fileinput.input():
        m = c.search(l)
        if m:
            print m.group()
            print m.groups()[0]; exit(1)

matchit()

