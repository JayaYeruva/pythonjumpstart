from sys import argv

def copyall(*files):
    if len(files) < 3:
        raise TypeError, \
               "copayall() expect at least 3 given {}".format(len(files))

    with open(files[-1], 'w') as fw:
        for filename in files[:-1]:
            fw.write(filename.center(60, '-')+"\n")
            fw.write(open(filename).read())
            fw.write('-'.center(60, '-')+"\n")

copyall(*argv[1:])
