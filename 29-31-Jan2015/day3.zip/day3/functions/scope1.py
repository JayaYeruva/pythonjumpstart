
n = 100  #global scope

def demo():
    print n
    #global n  #refer global version of n
    n = 'pypi' 
    print n


demo()
print n    
