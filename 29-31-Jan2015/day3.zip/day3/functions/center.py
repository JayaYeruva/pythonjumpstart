from math import ceil 

def center(s, w, fill=' '):
    n = (w - len(s))/2.0
    return (fill * int(ceil(n))) + s + (fill * int(n))

print center('perl', 7, '-')
print 'perl'.center(7, '-')
