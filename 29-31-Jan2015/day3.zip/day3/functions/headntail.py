
def headntail(filename, **param):
    count = param.get('count', 10)
    order = param.get('order', 'head')

    with open(filename) as fp:
        if order == 'head':
            content = fp.readlines()[:count]
        elif order == 'tail':     
            content = fp.readlines()[-count:] 
        else:
            raise ValueError, \
                "invalid value :{}".format(param['order'])
        return ''.join(content).rstrip('\n')

print headntail('/etc/passwd', count=4, order='tail')
