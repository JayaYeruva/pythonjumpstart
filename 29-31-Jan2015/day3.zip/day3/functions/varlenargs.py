
def demo(*args):
    print args
'''
demo()
demo(1)
demo('pypi')
demo(1,2,3,4)
demo('python', 5.8, 'patric')
'''
l = [1,2,3,4]
t = ('a', 'e', 'i')
demo(l)    
demo(*l)    
demo(t)    
demo(*t)    
