

def power(x, n=0):
    return x ** n

print power(5, 2)    
print power(5)    
