

def sum(a, b):
    def add(x):
        return x + b
    return add(a)
    
print sum(10, 11)        

print __file__
print __name__
