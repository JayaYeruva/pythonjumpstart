
def demo(**args):
    print args

demo()
demo(name='perl', author='wall', release='parrot', 
        version=12)


info = {'hostname' : 'ws1', 'ipaddr' : '127.0.0.1'}
demo(**info)    
