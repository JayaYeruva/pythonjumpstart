import re

s = 'root,x:0;0-root:/root /bin/bash'

l = re.split(r'[,:;\-\ ]', s)

print l
