
class RangeError(Exception):
    def __str__(self):
        return "{}: {}".format(self.__class__.__name__, self.message)

try:
    n = 6
    
    if n > 5:
        raise RangeError, "value not in the range: {}".format(n)

except RangeError, e:
    print e
