import fileinput
import re

def matchit():
    c = re.compile('\[\d+\.\d+\]')
    for l in fileinput.input():
        m = c.search(l)
        if m:
            print m.group()

matchit()

