
from sys import argv


def safe_float(value):
    
    try:
        temp = None
        temp = float(value[1])
    except ValueError, e:
        print e    
    except (KeyError, IndexError), e:    
        print e
    except Exception, e:
        print e    
    finally:
        print "finally block"
        return temp     

print safe_float(argv)    
