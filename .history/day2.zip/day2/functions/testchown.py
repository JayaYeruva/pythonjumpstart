#!/usr/bin/env python

import os
os.chown('catch22', 0, 54)
