#!/usr/bin/env python

from fileinput import input

for line in input():
    print line,

