#!/usr/bin/env python

#n = 100  #local variable to the script

def demo():
    global n
    n = 'python'
    print n

demo()
print n
