#from sys import path
#path.insert(0, 'lib') 
import myutils
import catch22

print myutils.name
