
print 'a sample module'
