#!/usr/bin/env python

#she- bang
#sha- bang
#comment python code 

name = raw_input('Enter the name : ')
city = raw_input('Enter the city : ')
zipcode = raw_input('Enter the zip : ')

print "Name :",name
print "City :",city
print "Zipcode :", zipcode
print "Type :", type(zipcode)

