#!/usr/bin/env python

#she- bang
#sha- bang
#comment python code 

name = input('Enter the name : ')
city = input('Enter the city : ')

print("Name :",name)
print("City :",city)

