#!/usr/bin/env python
import os

print os.getpid()

value = input('Enter the value : ')

print "value :",value
print "Type :", type(value)

