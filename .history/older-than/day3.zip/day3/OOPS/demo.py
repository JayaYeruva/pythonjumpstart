#!/usr/bin/env python

class Demo(object):
    '''
	a sample class in Python
    '''
    pass


d = Demo()
print d.__doc__ 
print d.__class__.__name__ 
print d 
print 
print Demo
