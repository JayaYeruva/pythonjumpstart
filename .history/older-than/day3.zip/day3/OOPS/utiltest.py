#!/usr/bin/env python
from utils import Utils
u  = Utils()
u.chown('passwd', 'ravi', 'root')
