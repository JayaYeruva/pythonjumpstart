#!/usr/bin/env python

class B(object):
  def pprint(self):
    print "pprint from the class B "


