#!/usr/bin/env python

class A(object):
  def pprint(self):
    print "pprint from the class A " 


