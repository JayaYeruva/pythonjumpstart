#!/usr/bin/env python

def add_item(name, quanity=1):
   print {name : quanity}


add_item('flour')
add_item('rice', 3)
add_item('cookies' )
