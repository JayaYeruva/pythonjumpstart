#!/usr/bin/env python

print __name__
