#!/usr/bin/env python

import sys
import pprint
pprint.pprint(open(sys.argv[1]).readlines())
