#!/usr/bin/env python

import utils
print utils.power(5,2)
