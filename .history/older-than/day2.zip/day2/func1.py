#!/usr/bin/env python

def sum(a, b):
   return a+b

#print  sum(2, 3)

func = sum
print func(10, 100)

