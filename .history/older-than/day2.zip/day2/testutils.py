#!/usr/bin/env python

import sys
sys.path.append('lib')
import utils
print utils.power(5,2)
