#!/usr/bin/env python

#sha bang

name = raw_input('Enter the name: ')
city = raw_input('Enter the city: ')
pin_code = raw_input('Enter the zip code: ')

print "Name :%s" % name
print "City :%s" % city
print type(pin_code)
print pin_code
