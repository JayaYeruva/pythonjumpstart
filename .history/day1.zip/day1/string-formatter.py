#!/usr/bin/env python

#sha bang

name = 'python'
city = 'huston'

print "%s  %s" % (name, city)
print "%10s  %s" % (name, city)
print "%-10s  %s" % (name, city)
