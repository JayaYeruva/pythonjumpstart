#!/usr/bin/env python
# -*- coding: utf-8 -*-

content = ur'ಮುಖ್ಯ ವಾರ್ತೆಗಳು\n‎ಕ್ರೀಡಾ ವಾರ್ತೆಗಳು\t‎ವಿಜಯ ಕರ್ನಾಟಕ'
print content
