#!/usr/bin/env python

print 'nelson',
print 'kimberly',
print 'amanda'

