#!/usr/bin/env python

value = input('Enter the value :')

print type(value)
print value
