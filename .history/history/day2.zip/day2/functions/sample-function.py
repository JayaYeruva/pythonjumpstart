#!/usr/bin/env python

def add(a, b):
    return a + b


test = add
print add
print test
print test(2,3)
