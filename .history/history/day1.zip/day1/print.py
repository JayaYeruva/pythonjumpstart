#!/usr/bin/env python

print 'james',
print 'kimberly',
print 'amanda',
print 'tim'
print 1,2,3,4,5
print 'nelson','manicam', 'pat';
