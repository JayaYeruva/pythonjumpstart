#!/usr/bin/env python
# -*- coding: utf-8 -*-
s = u"ಸೆಲೆಬ್ರಿಟಿ ಕ್ರಿಕೆಟ್ ಲೀಗ್ (ಸಿಸಿಎಲ್)ಗೆ ಇನ್ನು ಕೆಲವೇ ದಿನಗಳು ಮಾತ್ರ ಬಾಕಿ ಉಳಿದಿದೆ. ಈ ಬಾರಿ ಕರ್ನಾಟಕ ಬುಲ್ಡೋಜರ್ಸ್ ತಂಡದ ತಯಾರಿ ಕೂಡ ಜೋರಾಗಿ  Read more at: http://kannada.oneindia.in/" 
print s




