#!/usr/bin/env python

name = raw_input('enter the name :')
city = raw_input('enter the city :')
zipcode = raw_input('enter the zipcode :')

print "Name :", name
print "City :", city
print "Zip :", zipcode
print type(zipcode)



