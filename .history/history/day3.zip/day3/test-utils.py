#!/usr/bin/env python
import sys
#sys.path.insert(0, 'lib')
import utils22
from pprint import  pprint
print utils22.power(2,3)
