#!/usr/bin/env python

from getpass import getpass

passwd = getpass('Enter the password')
print passwd
