# -*- coding: utf-8 -*-
# <nbformat>3.0</nbformat>

# <codecell>

s = 'root:x:0:0:root:/root:/bin/bash'
users = s.split(':')
logins = s.split(':')[0]
print users
print logins

# <codecell>

l = ['root', 'x', '0', '0', 'root', '/root', '/bin/bash']
s = '|'.join(l)
print s

# <codecell>

line = "# the passwd file"
if line.startswith('#'):
    continue 

# <codecell>

s = [1, 3, 2, 5,4]
print sorted(s, reverse=True)
print s

# <codecell>

info = {'name': 'guido', 'lang': 'pypi', 
        'version':2.7, 'paltform': 'linux2'}
print info
print len(info)

# <codecell>

info = {'name': 'guido', 'lang': 'pypi', 'name': 'larry'
        'version':2.7, 'paltform': 'linux2'}
print info.keys()
print info.values()
print info.items()

# <codecell>

info = {'name': 'guido', 'lang': 'pypi', 
        'version':2.7, 'paltform': 'linux2'}

itemkey = 'paltform'
info['release'] = 'beffycow'   #add a new element

if itemkey in info:
    info[itemkey] = 'linux3'
    
print info

# <codecell>

info = {'name': 'guido', 'lang': 'pypi', 
        'version':2.7, 'paltform': 'linux2'}
value = info.pop('version')
print value
del info['name']
print info

# <codecell>

info = {'name': 'guido', 'lang': 'pypi', 
        'version':2.7, 'paltform': 'linux2'}

for k in sorted(info):
    print "{} -> {}".format(k, info[k])

# <codecell>

info = {'name': 'guido', 'lang': 'pypi', 
        'version':2.7, 'platform': 'linux2'}
print info['name']
print info['lang']
print info['version']
print info.get('platform')
print info.get('platfrm')
print info.get('platfrm', 'unknown')

# <codecell>

d = {}
l = ['key',2,3,4,5]
print l[0]
print l[1:]
d[l[0]] = l[1:]
print d

# <codecell>

l = [1, 2, 3] *  3
print list(set(l))

# <codecell>

a = set([1,3,5,7,9])
b = set([1,2,3,4,5])
print a.intersection(b)
print a.union(b)
print a - b
print b.difference(a)

# <codecell>

x = {i for i in range(1, 4)}
print x

# <codecell>

items = (1, 'two', 3, 4.4)
print items
print type(items)
print len(items)

# <codecell>

items = (1, 'two', 3, 4.4)

print items[-1]
print items[-2:]

# <codecell>

t = 1,2,'perl',4
print t

# <codecell>

#parallel assignment
(domain, app, version) = ('linux2', 'ws', '2.2')
print domain
print app
print version

# <codecell>

s = 'linux2,ws,2.2'
platform, app, version = s.split(',')
print platform
print app
print version

# <codecell>

a, b = 10, 'peter'
a, b = b, a
print a
print b

# <codecell>

def swapme(a, b):
    return b, a

print swapme(10, 2)

# <codecell>


