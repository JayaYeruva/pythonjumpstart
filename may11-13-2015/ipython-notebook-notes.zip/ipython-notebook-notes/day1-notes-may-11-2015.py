# -*- coding: utf-8 -*-
# <nbformat>3.0</nbformat>

# <codecell>

import sys
sys.path

# <codecell>

s = '"peter"'
print type(eval(s))

# <codecell>

'''
>, >=, <, <=, !=, ==

logical operator
and, not or 
'''

# <codecell>

#conditional operator
# true-part if test-condition else false-part

n = 5
res = n ** 2 if n>5 else n ** 3
print res

# <codecell>

print 5.8/2
print 5.8//2   #floor division

# <codecell>

n = 5
print n>=4 and n<=7
print not (4<=n<=7)

# <codecell>

'''
5 | 2 
101
010
----
111
'''
print 5 | 2

# <codecell>

'''
6 ^ 2
110
010
----
100
'''

print '6' ^ 2

# <codecell>

print type(6)
print type(6.1)
print type(int('6'))

# <codecell>

'''
~n
-n -1
'''
print ~(-5)

# <codecell>

'''
4 >> 1
100 >> 1
10
'''
print 4 >> 1

# <codecell>

'''
4 << 1
100 << 1
1000
'''
print 4 << 1

# <codecell>

print cmp('peter', 'peter')
print cmp('zee', 'peter')
print cmp('zee', 'zzz')
print ord('1')
print cmp(1, 49)

# <codecell>

print hash('1')
print hash(49)

# <codecell>

s = 'this is a sample string'
print 's i' in s
print 'z' not in s

# <codecell>

l = range(15)
print 100 not in l
print l

# <codecell>

print range(10)
print range(1,10)
print range(1, 10, 2)

# <codecell>

mat = [range(1, 4), range(4,7), range(7, 10)]
mat1 = [range(1, 4), range(4,7), range(7, 10)]
print mat
print mat1

# <codecell>

print range(1,4) * 2 
print range(1,4)  + range(5,9)

# <codecell>

print 2 ** 62
print 2 ** 64

# <codecell>

s = 'perl'
print s[-1]
print s[-2]
print s[-3]
print s[-4]

# <codecell>

'''
slicing

name[start-index:ex-of-end-index]
'''
s = 'perlandpython'
print s[:4]
print s[3:7]
print s[-6:]
#print s[:]
print s[:-1]

# <codecell>

'''
name[start-index:ex-of-end-index:occurance]
'''
s = 'perlandpython'
print s[::-2]
print s[1::2]
print s[::-1]

# <codecell>

l = [1, 'two', 3.0]
print l

# <codecell>

print ord('A')
print chr(65)

# <codecell>

import re
print re.search('perl', 'the perl scripting')
print re.search('pypi', 'the perl scripting')

# <codecell>

l = [1, 'two', 3.0]
print l
print len(l)

# <codecell>

l = [1, 'two', 3.0]
l.append('bangalore')
l.insert(0, 'intuit')
print l

# <codecell>

l = ['intuit', 1, 'two', 3.0, 'bangalore']
print len(l)
value =  l.pop()
print value
value =  l.pop(2)
print value
l.remove(3.0)
print l

# <codecell>

l = ['intuit', 1, 'two', 3.0, 'bangalore']
del l[-1]
del l

# <codecell>

l = ['intuit', 1, 'two', 3.0, 'bangalore']
3.0 in l

# <codecell>

l = ['intuit', 1, 'two', 3.0, 'bangalore']
l.reverse()
print l[::-1]

# <codecell>

l = [1,2,3.1,4,5, 'peter', 'emy', 'anderson', 'perterson', 'tim']
import random
random.shuffle(l)
print l

# <codecell>

l = ['anderson', 3.1, 5, 'peter', 'tim', 4, 'perterson', 'emy', 2, 1]
l.sort(reverse=True)
print l

# <codecell>

l = [1,2,3]
temp = ['pypi', 'cpan']
l.extend(temp)
print l

# <codecell>

l = [1,2,3]
temp = ['pypi', 'cpan']
print l + temp
print l

# <codecell>

l = [1, 2, 3, 'pypi', 'cpan']
for i in l:
    print i

# <codecell>

l = [1, 2, 3, 'pypi', 'cpan']
for (i, v) in enumerate(l):
    print "[{}] -> {}".format(i, v)

# <codecell>

l = [2, 3, 4, 5, 6]
temp = []
for i in l:
    temp.append(float(i))
    
print temp    

# <codecell>

l = [2, 3, 4, 5, 6]
print map(float, l)

# <codecell>

s = 'peter'
print map(ord, s)

# <codecell>


