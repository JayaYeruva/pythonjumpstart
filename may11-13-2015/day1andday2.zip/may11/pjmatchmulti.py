__author__ = 'ravi'
import re

s = 'the python scripting python python'

for m in re.finditer('Py', s, re.I):
    print "matched :", m.group()
    print m.span()
    print




