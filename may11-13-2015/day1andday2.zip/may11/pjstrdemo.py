__author__ = 'ravi'

path = 'c:\temp\nanacy\files\file1.txt'
print path

pat = r'\tabbing'

path = r'c:\temp\nanacy\files\file1.txt'
print path
