__author__ = 'ravi'

s = '12.12'
it = iter(s)
while True:
    try:
        print it.next()
    except StopIteration:
        break



