__author__ = 'ravi'

s = '12.12'

for item in s:
    print "{} : {}".format(item, ord(item))
