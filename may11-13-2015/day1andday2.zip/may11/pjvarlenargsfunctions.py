__author__ = 'ravi'

def demo(*args):
    print args


demo()
demo(1)
demo('peter')
demo(1, 2, 3,4.1,'five')

l = [1,2,3,4,5]
demo(l)
demo(*l)