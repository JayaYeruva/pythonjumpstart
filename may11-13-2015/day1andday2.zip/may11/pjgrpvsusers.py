__author__ = 'ravi'

from pprint import pprint

users = {l.split(':')[0] for l in open('/etc/passwd')}
groups = {l.split(':')[0] for l in open('/etc/group')}

uwg = users.intersection(groups)
#pprint(uwg)

uwog = users.difference(groups)
#pprint(uwog)

gwou = groups.difference(users)
print "Group Without User"
for item in gwou:
    print item
