__author__ = 'ravi'
import re

s = 'the python scripting'
m = re.match('PythoN', s)

if m:
    print m
    print "we got a match :)"
else:
    print "failed to match :("


