__author__ = 'ravi'

name = 'pam'
age = 4
gender = 'female'

print "|{:^12}|{:^5}|{:^10}|".format('name', 'age', 'gender')
print "|{}|{}|{}|".format(name, age, gender)
print "|{:>12}|{:>5}|{:>10}|".format(name, age, gender)
print "|{:<12}|{:<5}|{:<10}|".format(name, age, gender)
print "|{:^12}|{:^5}|{:^10}|".format(name, age, gender)
print "|{:12}|{:5}|{:10}|".format(name, age, gender)
