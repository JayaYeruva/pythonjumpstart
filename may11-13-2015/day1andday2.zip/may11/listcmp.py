__author__ = 'ravi'

l = [4, 2, 6, 5]

temp = []

for i in l:
    temp.append(i ** i)

print temp

temp2 = [i ** i for i in l]
print temp2
