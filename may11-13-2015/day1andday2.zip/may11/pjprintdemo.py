__author__ = 'ravi'

print 'amanda',
print 'kim',
print 'tim',
print 'pam',
print 'steve'

print 1,2,3,4,5

