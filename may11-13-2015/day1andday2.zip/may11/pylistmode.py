__author__ = 'ravi'
names = ['eva', 'sam', 'pam', 'tim']
age = [2, 3, 1]
gender = ['f', 'm', 'f', 'm']

'''
parallel iteration
'''
print zip(names, age, gender)


for (n, a, g) in zip(names, age, gender):
    print "{:>16} {:>5} {:>5}".format(n, a, g)