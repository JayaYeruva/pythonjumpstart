__author__ = 'ravi'
from pprint import pprint

ul = [l.split(':')[0].upper()
             for l in open('/etc/passwd') if l.startswith('a')]

ul = sorted(ul)
pprint(ul)
