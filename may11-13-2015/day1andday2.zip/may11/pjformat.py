__author__ = 'ravi'

import math
radius = 2.2
area = math.pi * (radius ** 2)
'''
{index:formatter}
'''

res = "radius : {1}\narea : {0:.3f}".format(radius, area)
print res