__author__ = 'ravi'
from json import load
from pprint import pprint

content = load(open('passwd.json'))
#pprint(content)

for i in sorted(content):
    print "{}:{}".format(i, content[i][-1])

