__author__ = 'ravi'

print "hello " * 5
