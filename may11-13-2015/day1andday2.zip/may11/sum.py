__author__ = 'ravi'

a = int(raw_input('Enter the a :'))
b = raw_input('Enter the b :')

print a + int(b)
