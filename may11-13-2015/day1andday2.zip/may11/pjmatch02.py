__author__ = 'ravi'
import re

s = 'the python scripting python python python'
m = re.search('PythoN', s, re.I)

if m:
    print m
    print "matched :", m.group()
    print m.start()
    print m.end()
    print m.span()
else:
    print "failed to match :("


