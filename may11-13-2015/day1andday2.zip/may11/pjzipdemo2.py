__author__ = 'ravi'

tags = ['hostname', 'domain']
values = ['ws1', 'rootcap.in']

info = dict(zip(tags, values))
print info
print zip(tags, values)
print info.items()