__author__ = 'ravi'
import re

s = 'root,x:0;0-/root:/bin/bash'

l = re.split('[,:;\-:]', s)
print l
