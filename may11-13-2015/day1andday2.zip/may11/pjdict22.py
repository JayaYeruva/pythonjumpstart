__author__ = 'ravi'

data = {i: bin(i) for i in range(1, 6)}

print data
