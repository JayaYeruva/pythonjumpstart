__author__ = 'ravi'

value = input('enter the value :')
print value
print type(value)