__author__ = 'ravi'

word_count = {}

for line in open('lorem.txt'):
    for word in line.rstrip().split(' '):
        if word in word_count:
            word_count[word] += 1
        else:
            word_count[word] = 1

for word in sorted(word_count):
    print "{} : {}".format(word, word_count[word])