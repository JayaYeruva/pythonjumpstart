__author__ = 'ravi'

import fileinput

for line in fileinput.input(inplace=True, backup='.back'):
    print "{:>6}  {}".format(fileinput.lineno(), line.rstrip())
