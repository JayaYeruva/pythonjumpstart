__author__ = 'ravi'
from pprint import  pprint
from json import dump

content = {}

with open('/etc/passwd') as fp:
    for line in fp:
        temp = line.rstrip().split(':')
        content[temp[0]] = temp[1:]

dump(content, open('passwd.json', 'w'), indent=4)


