# -*- coding:utf-8 -*-
__author__ = 'ravi'

s = ur'content\tgoes\nright here'
print s
