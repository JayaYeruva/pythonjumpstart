__author__ = 'ravi'

import math

radius = 2.2
area = math.pi * (radius ** 2)
'''
string formatting
'''
result =\
    "radius: %s\narea : %.2f" % (str(radius), area)

print result
