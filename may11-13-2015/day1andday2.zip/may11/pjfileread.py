__author__ = 'ravi'
'''
with open('/etc/resolv.conf') as fp:
    for line in fp:
        if line.startswith('#'):
            continue
        print line.rstrip()
'''

with open('/etc/resolv.conf') as fp:
    print fp.read()
