__author__ = 'ravi'

i = 1

while i <= 5:
    if i == 3:
        break
    elif i == 1:
        print 'one'
    else:
        print i
    i += 1
else:
    print "else block of the while loop"

print "am out of loop"