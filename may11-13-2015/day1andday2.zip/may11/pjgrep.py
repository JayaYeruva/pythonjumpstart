__author__ = 'ravi'
import re
from sys import argv
from fileinput import input

pattern = argv.pop(1)

for line in input():
    if re.search(pattern, line, re.I):
        print line.rstrip()

