__author__ = 'ravi'



mat = [[1, 2, 3],
       [4, 5, 6, 10],
       [7, 8, 9]]

print [c for r in mat if len(r)==3 for c in r if c%2==0]
'''
print [ bin(i[1]) for i in mat[::-1]]

for item in  [i[1] for i in mat[::-1]]:
    print item
'''