__author__ = 'ravi'
from pprint import pprint


userlist = []

with open('/etc/passwd') as fp:
    for line in fp:
        userlist.append(line.split(':')[0])


for index, login in enumerate(sorted(userlist), 1):
    print "{:>6}  {}".format(index, login)