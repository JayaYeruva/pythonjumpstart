__author__ = 'ravi'

name = raw_input('Enter the name :')
city = raw_input('Enter the city :')
zipcode = int(raw_input('Enter the zip code :'))

print 'name :', name
print 'city :', city
print zipcode
print type(zipcode)


