__author__ = 'ravi'

word_count = {}

for line in open('lorem.txt'):
    for word in line.rstrip().split(' '):
        if len(word):
            word_count[word] = word_count.get(word, 0) + 1


for word in sorted(word_count):
    print "|{}| : {}".format(word, word_count[word])