__author__ = 'ravi'


def center(string_content, width, fill_char=' '):
    n_times = (width - len(string_content)) / 2
    return "{}{}{}".format(fill_char * n_times,
                           string_content, fill_char * n_times)

print center('perl', 7, '*')
print 'perl'.center(9, '*')
