__author__ = 'ravi'

import MySQLdb

conn = MySQLdb.connect('localhost', 'root', 'password', 'may13')

query = 'select version()'

cur = conn.cursor()
cur.execute(query)
print cur.fetchone()[0]

#print dir(cur)
cur.close()
conn.close()
