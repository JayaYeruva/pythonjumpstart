__author__ = 'ravi'


def head_n_tail(file_name, **param):
    count = param.get('count', 10)
    order = param.get('order', 'head')
    content = ''

    if order == 'head':
        content = open(file_name).readlines()[:count]
    elif order == 'tail':
        content = open(file_name).readlines()[-count:]

    return ''.join(content).rstrip()

print head_n_tail('/etc/passwd', count=4, order='head')