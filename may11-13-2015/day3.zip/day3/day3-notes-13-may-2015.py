# -*- coding: utf-8 -*-
# <nbformat>3.0</nbformat>

# <codecell>

l = [1,2,3,4,5,6]
print l[:3]
print l[-3:]

# <codecell>

help(file.readlines)

# <codecell>


# <codecell>

import os
os.listdir('.')

# <codecell>

import os
os.environ

# <codecell>


# <codecell>

import os
os.listdir('path')

# <codecell>

import os.path
print os.path.isfile('/etc/passwd')
print os.path.isdir('/etc/passwd')

# <codecell>

import os
print os.stat('/etc/passwd')
print os.stat('/etc/passwd').st_size

# <codecell>

path='/usr/bin'
file = 'ls'
from os.path import join
print join(path, file)

# <codecell>


# <codecell>


# <codecell>

import subprocess
op =  subprocess.check_output('ls -l| head -3', shell=True, )
print op.upper()

# <codecell>


# <codecell>


# <codecell>


