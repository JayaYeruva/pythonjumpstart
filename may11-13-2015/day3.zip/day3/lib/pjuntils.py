'''
utils a sample python module
'''
import os

company = 'psf'
version = '0.0.1 beta'


def get_process_ids():
    '''
    get_process_ids()
    gets current and the parent process id
    :return:None
    '''
    print "current process id ", os.getpid()
    print "parent process id ", os.getppid()

def ls(path='.'):
    '''
    ls(), list the content of the given directory
    :param path: str: a valid filesys path
    :return: None
    '''
    for file_name in os.listdir(path):
        print file_name

class Demo(object):
    '''
    Demo
    a dummy python class
    '''
    pass

def main():
    print __name__  #__main__
    print company
    ls()
    get_process_ids()

if __name__ == '__main__':
    main()

