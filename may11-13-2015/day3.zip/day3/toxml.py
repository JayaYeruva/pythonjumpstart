__author__ = 'ravi'
from xml.etree.ElementTree import Element, SubElement, ElementTree
import sys

root = Element('diectory')
root.attrib['name'] = '/etc/'

files = SubElement(root, 'files')
file_tag = SubElement(files, 'file')
file_tag.text = 'passwd'
file_tag.attrib['size'] = '1234'

et = ElementTree(root)

et.write('files.xml')