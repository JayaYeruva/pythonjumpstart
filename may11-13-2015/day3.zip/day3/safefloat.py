__author__ = 'ravi'
from sys import argv

def safe_float(value):
    try:
        result = None
        result = float(value[1]) /0
    except ValueError, e:
        print e
    except (KeyError, IndexError), e:
        print "its may be key or index error"
    except:
        print "internal server error"
    finally:
        print "finally of the exception handling"
        return result

print safe_float(argv)
