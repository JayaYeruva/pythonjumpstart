__author__ = 'ravi'
from sys import argv


def reverse_copy(source_file, dest_file):
    with open(dest_file, 'w') as fw:
        fw.writelines(open(source_file).readlines()[::-1])

def usage():
    print "Usage:"
    print "{} source-file dest-file".format(argv[0])
    exit(1)

if len(argv) != 3:
    usage()

reverse_copy(argv[1], argv[2])
