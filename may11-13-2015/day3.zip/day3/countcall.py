__author__ = 'ravi'

counter = 0

def get_check():
    global counter
    counter += 1

get_check()
get_check()
get_check()
print counter
