__author__ = 'ravi'


class RangeError(Exception):
    def __str__(self):
        return "{}: {}".format(self.__class__.__name__, self.message)

try:
    radiation = 0.7
    if radiation > 0.4:
        raise RangeError, "radiation level is too high: {}".format(radiation)

except RangeError, e:
    print e