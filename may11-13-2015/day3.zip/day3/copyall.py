__author__ = 'ravi'
from sys import argv


def copy_all(*filenames):
    with open(filenames[-1], 'w') as fw:
        for file_name in filenames[:-1]:
            fw.write(file_name.center(60, '-') + '\n')
            fw.write(open(file_name).read())
            fw.write('-'.center(60, '-') + '\n')

copy_all(*argv[1:])
