__author__ = 'ravi'

from person import Person

class Employee(Person):
    def __init__(self, eid, first_name, last_name, age, gender, desg):
        self.eid = eid
        self.desg = desg
        '''
        calling base version of __init__()
        '''
        super(Employee, self).__init__(first_name, last_name, age, gender)

    def get_info(self):
        print "employee id : {}".format(self.eid)
        super(Employee, self).get_info()
        print "designation : {}".format(self.desg)

def main():
    p = Employee('v4001', 'tim', 'worthy', '4', 'gender', 'clerk')
    p.get_info()

if __name__ == '__main__':
    main()
