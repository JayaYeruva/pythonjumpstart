__author__ = 'ravi'
from pprint import pprint
import os
from os.path import isfile, join

class Dir2Dict(object):
    def __init__(self, directory_path):
        self.content = {}
        self.directory_path = directory_path
        self.__read_directory()

    def __read_directory(self):
        file_info = {}
        for name in os.listdir(self.directory_path):
            abs_path = join(self.directory_path, name)

            if isfile(abs_path):
                file_info[name] = os.stat(abs_path).st_size

        self.content[self.directory_path] = file_info

def main():
    d = Dir2Dict('/tmp')
    pprint(d.content)

if __name__ == '__main__':
    main()
