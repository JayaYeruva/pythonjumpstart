__author__ = 'ravi'

class Demo(object):
    def __init__(self):
        print "{} in the constructor".format(self)

    def __del__(self):
        print "destorying : {}".format(self)

def main():
    d = Demo()
    print d

if __name__ == '__main__':
    main()

