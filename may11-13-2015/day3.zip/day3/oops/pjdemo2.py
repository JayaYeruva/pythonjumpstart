__author__ = 'ravi'
import os
from sys import argv

class Process(object):
    def __init__(self):
        self.pid = os.getpid()

    def get_process_id(self):
        return self.pid

class GetApp(object):
    def __init__(self, data):
        self.data = "{}: {}".format(argv[0], data)

    def get_data(self, ):
        return self.data

    def __del__(self):
        print "destorying : {}".format(self)

def main():
    p = Process()
    d = GetApp(p.get_process_id())
    print d.get_data()

if __name__ == '__main__':
    main()

