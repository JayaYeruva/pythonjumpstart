__author__ = 'ravi'


class Person(object):
    def __init__(self, first_name, last_name, age, gender):
        self.first_name = first_name
        self.last_name = last_name
        self.age = age
        self.gender = gender

    def get_info(self):
        print "first name : {}".format(self.first_name)
        print "last name : {}".format(self.last_name)
        print "age : {}".format(self.age)
        print "gender : {}".format(self.gender)


def main():
    p = Person('tim', 'worthy', '4', 'clerk')
    p.get_info()

if __name__ == '__main__':
    main()
