__author__ = 'ravi'

def demo(**args):
    if 'version' in args:
        return args['version']



info = {'host': 'ws1', 'domain': 'rp.in'}

print demo()
print demo(name='larry', lang='perl', version='5.18')
print demo(**info)
