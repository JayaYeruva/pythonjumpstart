__author__ = 'ravi'

n = 'pypi'  #global scope

def demo():
    global n
    n = 100
    print "with in the function :", n

demo()
print n

