#!/usr/bin/env python

char = 'x'

s = '''
   1
  2 2
 3 %s 3
  4 4
   5
''' % char

print s
