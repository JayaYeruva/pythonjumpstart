#!/usr/bin/env python

l = [1001, 'sam', 'male', 4500.12, 'manager', None]
print l
l[-1] = 'lenovo'

print l[-2]
print l[-3]

print l

