#!/usr/bin/env python
value = input('Enter the value :')

print value
print type(value)

