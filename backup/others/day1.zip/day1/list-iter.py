#!/usr/bin/env python

items = ['abab', 'alphine', 'abe',  'e', 'i', 'o', 'u', 1, 3 ,5 ,7];

for item in items:
    print item
