#!/usr/bin/env python

print 'kimberly',
print 'amanda',
print 'sam',
print 'pam',
print 'nelson'

