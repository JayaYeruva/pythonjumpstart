#!/usr/bin/env python

l = [1001, 'sam', 'male', 4500.12, 'manager', 'alpha', 4, 'zee', 5 , 23, 1]
l.sort(reverse=True)
#l.reverse()

nums = l[-6:]
strs = l[:-6]
print nums
print strs
print l


