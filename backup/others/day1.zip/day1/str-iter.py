#!/usr/bin/env python

city = 'ny'
i = 1

for c in city:
    #in the code block of the loop
    print c * i
    i += 1

#out of the loop
print 'its ends here'


