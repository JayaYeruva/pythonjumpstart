#!/usr/bin/env python

l = [1001, 'sam', 'male', 4500.12, 'manager']
del l[1]
del l

print l


