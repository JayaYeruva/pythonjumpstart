#!/usr/bin/env python

name = 'lenovo'
city = 'bangalore'

print "Name :",name
print "City :", city

