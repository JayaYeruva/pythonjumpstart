#!/usr/bin/env python


print 'I am\tpeter\nfrom\tdown town';
print r'I am\tpeter\nfrom\tdown town';
