#!/usr/bin/env python

s = 'alpha'

for item in s:
    print "%s : %s" % (item, ord(item))
