#!/usr/bin/env python

l = [1001, 'sam', 'male', 4500.12, 'manager']
print l

'''
l.append('sales')
l.append('bangalore')
print l; print
value = l.pop()
print value
'''

l.insert(0, 'intel');
print l
value = l.pop(0)
print value
print l

