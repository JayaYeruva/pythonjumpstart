#!/usr/bin/env python

name = raw_input('Enter the name :')
city = raw_input('Enter the city :')
zipc = raw_input('Enter the pincode :')

print "Name :",name
print "City :", city
print zipc
print type(zipc)

