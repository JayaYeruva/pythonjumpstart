#!/usr/bin/env python

def demo(seq):
    seq.pop()
    

l = ['amanda', 'aman', 'amit']

demo(l)
print l

