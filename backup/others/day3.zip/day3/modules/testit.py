import sys

#sys.path.insert(0, 'lib');

from sample import swapme, name, version

print swapme('peter', 'helen')
print name
print version
