import sys

import check
print check.runme('ls')
