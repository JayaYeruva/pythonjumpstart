#!/usr/bin/env python

info = {'name' : 'guido', 'lang' : 'python', 'city':'san jose', 'area': 'lakeview'}

print info['name']
print info['lang']
print info['city']

print info
