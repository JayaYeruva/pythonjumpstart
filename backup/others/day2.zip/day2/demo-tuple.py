#!/usr/bin/env python

t = (1,2,3,4.23, 'jane & jack')
print t
print len(t)
print type(t)

#t[0] = 'one'
print t[-1]
print t[-2]

print t[-3:];print 

for item in t:
   print item


