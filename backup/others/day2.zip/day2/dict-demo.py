#!/usr/bin/env python

info = {'name' : 'python', 'version' : '2.7.6', 'release' : 'sphereical'}
print len(info)
print type(info)
print info
