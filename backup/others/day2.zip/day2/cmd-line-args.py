#!/usr/bin/env python

import sys 

print sys.argv
