__author__ = 'ravi'

print 'amanda',
print 'kimberly',
print 'jane',
print
print 'tim',
print 'jack',
print 'nelson'
