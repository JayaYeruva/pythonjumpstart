__author__ = 'ravi'

l = [1, 1.0, 'one', 3+4j]
another = ['0x1', '0x11']
"""
l.extend(another)
"""
new = l * 2 #+ another

print new

