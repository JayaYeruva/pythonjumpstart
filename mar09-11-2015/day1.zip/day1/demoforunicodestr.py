#!/usr/bin/env python
# -*- coding:utf-8 -*-


s = u"पहुंचीं ममता\nआज करेंगी\tपीएम से मुलाकात"

print s
print

s = ur"पहुंचीं ममता\nआज करेंगी\tपीएम से मुलाकात"

print s