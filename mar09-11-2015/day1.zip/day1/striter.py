__author__ = 'ravi'

s = 'py ton'

for i in s:
    print "{} : {}".format(i, ord(i))