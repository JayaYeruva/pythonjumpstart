__author__ = 'ravi'
"""
the values that gets boolean False
"""
print bool(0)
print bool(0L)
print bool(0.0)
print bool(0+0j)
print
print bool('')
print
print bool([])
print bool(())
print bool({})
print bool(None)