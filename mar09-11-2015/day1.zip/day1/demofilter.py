__author__ = 'ravi'

temp = list()
l = range(1, 11)

for i in l:
    if i % 2 == 0:
        temp.append(i)

print temp