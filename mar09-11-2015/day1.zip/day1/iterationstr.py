__author__ = 'ravi'

s = 'pypi'
i = 1

for item in s:
    print item * i  # item.__mul__(i)
    i += 1
