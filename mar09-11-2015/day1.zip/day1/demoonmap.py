__author__ = 'ravi'

a = [2,3,4]
b = [1,2,3]

print map(lambda x, n: x ** n, a, b)
