__author__ = 'ravi'

s = 'c:\\nancy\\temp\\template.data'
print s

"""
raw string
"""
print

s = r'c:\nancy\temp\template.data'
print s
