__author__ = 'ravi'

s = """
    1
   2 2
  3 {} 3
   4 4
    5
""".format('x').strip('\n')

print '-' * 5
print s
print '-' * 5