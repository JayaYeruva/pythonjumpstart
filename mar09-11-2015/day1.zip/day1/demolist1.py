__author__ = 'ravi'

l = [1, 1.0, 'one', 3+4j]

"""
l.append('intuit')
l.insert(0, 'bangalore')
"""
value = l.pop(-2)
print value
print l

