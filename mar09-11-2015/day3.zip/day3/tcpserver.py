__author__ = 'ravi'
import SocketServer

class RequestHandler(SocketServer.BaseRequestHandler):
    def handle(self):
        content = ''
        for item in  self.request.recv(1024):
            content += item

        self.request.sendall(content.upper())


addr = ("localhost", 9090)

tcp = SocketServer.TCPServer(server_address=addr, RequestHandlerClass=RequestHandler)
tcp.serve_forever()
