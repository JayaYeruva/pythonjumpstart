__author__ = 'ravi'

class Demo(object):
    pass

d = Demo()

print Demo
print type(Demo)
print d
print type(d)