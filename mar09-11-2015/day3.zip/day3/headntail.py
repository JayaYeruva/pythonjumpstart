__author__ = 'ravi'

class Utils(object):

    def __init__(self, file_name=None):
        self.file_name = file_name
        self.order = None
        self.count = None

    def headntail(self, **param):
        """
        :param param: default value order : head, count:10
        :return:
        """
        self.order = param.get('order', 'head')
        self.count = param.get('count', 10)
        content = open(self.file_name).readlines()

        if self.order == 'head':
            temp = content[:self.count]
        elif self.order == 'tail':
            temp = content[-self.count:]

        return ''.join(temp)


if __name__ == '__main__':
    u = Utils('/etc/passwd')
    print u.headntail(order="tail", count=3)

