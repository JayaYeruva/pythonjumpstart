__author__ = 'ravi'
import threading
import subprocess
import json
import fileinput
from sys import argv


class ParallelPing(object):
    def __init__(self, hostlist):
        self.hostlist = hostlist
        self.__host_status = {}

    def ping(self, host_id):
        print "thread : {}".format(threading.current_thread().name)
        return_value = subprocess.call(r'ping -c 1 {} '.format(host_id),
                                       shell=True, stdout=subprocess.PIPE)

        self.__host_status[host_id.rstrip()] = \
            "up" if return_value == 0 else "fails"

    def get_host_status(self):
        return self.__host_status

    def check_host(self):
        temp = []
        for host_id in fileinput.input(files=[self.hostlist]):
            t = threading.Thread(target=self.ping, args=(host_id,),
                                 name=host_id)
            t.start()
            temp.append(t)

        for t in temp:
            t.join()

class ParallelPingExecution(ParallelPing):
    """
    method overriding
    """
    def __init__(self, host_list):
        super(ParallelPingExecution, self).__init__(host_list)

    def execute_get_json(self):
        self.check_host()
        return json.dumps(self.get_host_status(), indent=2)

if __name__ == '__main__':
    p = ParallelPingExecution(argv[1])
    print p.execute_get_json()
