__author__ = 'ravi'

class Demo(object):
    def __init__(self):
        print "constructor function {}".format(self)

    def __del__(self):
        print "destructor "

d = Demo()
print d
