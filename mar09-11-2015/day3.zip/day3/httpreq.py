import requests

r = requests.get('http://python.org')
print r.text
