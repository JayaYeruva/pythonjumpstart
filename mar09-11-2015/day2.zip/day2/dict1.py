__author__ = 'ravi'

info = dict(name='python', version='2.7', author='rossum')

print info
print len(info)
print type(info)
