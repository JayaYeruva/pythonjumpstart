__author__ = 'ravi'

#tuple
#readonly list
#immutable

t = 1, 2.0, 'three', 4+0j
for item in t:
    print item

