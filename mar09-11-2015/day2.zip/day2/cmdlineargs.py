__author__ = 'ravi'
from sys import argv
print argv

print argv[0]

print argv[1]