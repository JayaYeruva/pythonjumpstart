import subprocess

cat = subprocess.Popen('cat /etc/hostname', shell=True, \
             stdout=subprocess.PIPE, stderr=subprocess.PIPE)

tr = subprocess.Popen('tr "a-z" "A-Z"', shell=True, \
    stdin=cat.stdout, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

print tr.communicate()
print tr.returncode

