
class Person(object):
    def __init__(self, firstname, lastname):
        self.firstname = firstname
        self.lastname = lastname 


    def getinfo(self):
        print "first name : {}".format(self.firstname)    
        print "last name : {}".format(self.lastname)    


if __name__ == '__main__':
    p = Person('larry', 'wall')
    p.getinfo()        
