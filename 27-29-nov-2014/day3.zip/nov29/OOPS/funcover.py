

def demo():
    print 'a sample function'

def demo(a, b):
    print a, b 
    
demo()       
