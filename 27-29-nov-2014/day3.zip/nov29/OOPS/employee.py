from person import Person

class Employee(Person):
    def __init__(self, eid, firstname, lastname, desg):
        self.eid = eid
        self.desg = desg

        super(Employee, self).__init__(firstname, lastname)
        #above calls overridden method

    def getinfo(self):
        print "employee id : {}".format(self.eid)
        super(Employee, self).getinfo()
        print "designation  : {}".format(self.desg)

if __name__ == '__main__':
    e = Employee('v4001', 'paul', 'allen', 'clerk')
    e.getinfo()        
            
