#!/usr/bin/env python

class Demo(object):
    def __init__(self, value):
        self.value = value
       
    def getvalue(self):
        return self.value    

    def __del__(self):
        print "geting destroyed....."

if __name__ == '__main__':
    d = Demo('pypi')  #instance
    print d
    print d.getvalue()            
