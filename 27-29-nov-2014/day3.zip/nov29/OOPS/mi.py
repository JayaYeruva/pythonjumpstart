#!/usr/bin/env python

class A(object):
    def pprint(self):
        print 'pprint form the class A'

class B(object):
    def pprint(self):
        print 'pprint form the class B'

class C (B, A):
    def pprint(self):
        #super(C, self).pprint()
        A.pprint(self)
        B.pprint(self)

if __name__ == '__main__':
    c = C()
    c.pprint()                
