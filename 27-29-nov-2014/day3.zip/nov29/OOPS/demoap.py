
class Person(object):
    def __init__(self, firstname, lastname):
        self.__firstname = firstname
        self.lastname = lastname 
    
    def wrap(self):
        self.__getinfo()

    def __getinfo(self):
        print "first name : {}".format(self.__firstname)    
        print "last name : {}".format(self.lastname)    


if __name__ == '__main__':
    p = Person('larry', 'wall')
    #print dir(p)
    p._Person__getinfo()

