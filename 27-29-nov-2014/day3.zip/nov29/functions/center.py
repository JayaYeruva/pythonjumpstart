from math import ceil
def center(s, w, fill=' '):
   diff = (w - len(s))/2.0
   lhs = int(ceil(diff))
   rhs = int(diff)
   return "{}{}{}".format(fill * lhs, s, fill*rhs)

print center('pypi', 7, '-')   
print center('pypi', 7)   

