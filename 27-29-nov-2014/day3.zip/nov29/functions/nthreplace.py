import re

s = 'this is a sample string'
count = 0

def fixit(m):
    global count
    count += 1
    return '*' if count == 3  else m.groups()[0]

print re.sub(r'([AEIOU])', fixit, s, flags=re.I)
