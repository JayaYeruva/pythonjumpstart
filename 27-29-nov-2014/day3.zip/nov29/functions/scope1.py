
n = 100  #lives in global scope 

def toupper():
    global n
    n = n.upper()
    print n

def demo():
    global n
    n = 'perl'
    print n


demo()
toupper()
print n
