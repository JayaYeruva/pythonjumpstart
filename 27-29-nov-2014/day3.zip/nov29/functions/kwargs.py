def demo(**args):
    print args

demo()    
demo(hostname='ws1', doamin='rootcap.in', paltform='linux2')

info = {'lang' : 'perl', 'author': 'wall', 'version' : 5.19}
demo(**info)
