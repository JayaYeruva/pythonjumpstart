#!/usr/bin/env python

l = [1,2,3,4,5]

def mymap(cb, seq):
    #print func(5); exit(1)
    return [ cb(i) for i in  seq]

print mymap(bin, l)

print map(lambda s: "<bin>{}</bin".format(s), map(bin, l))

