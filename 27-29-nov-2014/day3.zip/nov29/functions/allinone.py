def demo(a, b, *args, **kwargs):
    pass

def demo2(a, b, **kwargs, *args):
    pass
