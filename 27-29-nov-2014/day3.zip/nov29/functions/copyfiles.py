#!/usr/bin/env python
from sys import argv

def copyall(*files):
    print "length of the args : {}".format(len(files))

    with open(files[-1], 'w') as fw:
        for filename in files[:-1]:
            fw.write(filename.center(60, '-')+'\n')
            fw.write(open(filename).read())
            fw.write('-'.center(60, '-')+'\n')

copyall(*argv[1:])    
