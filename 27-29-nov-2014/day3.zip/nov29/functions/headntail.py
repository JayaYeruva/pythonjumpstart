#!/usr/bin/env python

def headntail(filename, **param):
    count = param.get('count', 10)
    order = param.get('order', 'head')
    lines = open(filename).readlines()
    if order == 'head':
        content = lines[:count]
    elif order == 'tail':
        content = lines[-count:]
    return ''.join(content)    

print headntail('/etc/passwd', count=3, order='tail').rstrip()
    
#headntail('/etc/passwd', count=5, order='head')    
