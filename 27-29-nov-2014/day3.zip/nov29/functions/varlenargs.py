#!/usr/bin/env python

def demo(*args):
    print args


#demo()
#demo(1)
#demo('one')    
#demo(1,2,3,4,5)
l = [1,2,3]
t = (4,5,6)
demo(l)
demo(*l)
demo(t)
demo(*t)
