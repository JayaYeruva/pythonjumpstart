
def myfilter(cb, s):
    return [ i for i in s if cb(i)]

l = range(1, 16)
print myfilter(lambda n: n%2==0, l)    
print filter(lambda n: n%2==0, l)    
