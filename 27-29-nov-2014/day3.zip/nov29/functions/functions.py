def power(x, n=0):
    return x ** n

print power(3, 4)    
print power(3)    
