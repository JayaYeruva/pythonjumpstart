
def sumit(a, b):
    def add(x):
        return x + b
    return add(a)

print sumit(10, 11)    

print __name__
print __file__
