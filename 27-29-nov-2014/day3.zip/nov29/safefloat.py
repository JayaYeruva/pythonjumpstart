from sys import argv

def safefloat(value):
    try:
        #raise Exception, 'internal server error'
        return float(value[1])

    except ValueError, e:
        print e    
    except (IndexError, KeyError), e:
        print e     
    except Exception, e:
        print e
    finally:
        print 'am infinally block'        

print safefloat(argv)
