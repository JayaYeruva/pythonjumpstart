import re

s = 'this is a sample string'

print re.sub('[AEIOU]', '*', s, flags=re.I)
