#!/usr/bin/env python
import re
import fileinput
#Nov 17 22:22:23
pattern = r'([a-z]{3})\ ([0-9]{2})\ ([0-9]{2}:\d{2}:\d{2})'

for l in fileinput.input(inplace=True, backup='.bak'):
    print re.sub(pattern, r'[\3] \2, \1', l, flags=re.I).rstrip()
