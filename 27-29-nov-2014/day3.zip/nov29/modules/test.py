from sys import path
path.insert(0, 'lib22')

import utils

print utils.name
print utils.power(1, 2)

