#!/usr/bin/env python

from sys import path
from pprint import pprint
pprint(path)
