'''Uitls, a sample python module
author : jaya
'''

name = 'uitls, a sample module'
version = '0.1'

def swapme(a, b):
    '''swapme(a, b) returns b, a
        swapme swaps the arguments
    '''
    return b, a
    
def power(x, n):
    '''power(x, n) return int
        raises x to the power of the n
    '''    
    return x ** n        

class Shell(object):
    '''Shell a dummy class
    '''

    def ls(self, dirname='.'):
        ''' ls(dirname) return content of the directory
        '''
        from os import listdir
        for fn in listdir(dirname):
            print fn

if __name__ == '__main__':            
    print name
    print power(2, 3)
    sh = Shell()
    sh.ls()
    
