
class RangeError(Exception):
    pass


try:
    n = 6
    if n > 5:
        raise RangeError, \
                "{}: value not in the range".format(n)

except RangeError, e:
    print e
    print type(e)


                
