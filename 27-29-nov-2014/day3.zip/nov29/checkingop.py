#!/usr/bin/env python

import subprocess 
try:
#op = subprocess.check_output(['ls', '-l', '/data/'])
    op = subprocess.check_output('ls -l /data1', shell=True)
    print op
    
except subprocess.CalledProcessError, e:
    print e.returncode


