__author__ = 'ravi'

l = [1, 12.12, 'almighty', 'perl']
print l
print len(l)
print type(l)
