__author__ = 'ravi'
s = 'aeiou'
i = 1
for char in s:
    print "{}".format(char*i)
    i += 1

