__author__ = 'ravi'

l = [1, 12.12, 'almighty', 'perl']
l[-1] = 'python'
l[0] = 'one'

print l
