#!/usr/bin/env python
i = 1

while i<=20:
    if i%4 == 0:
        print i+1
    #if i==3:
    #    break
    i += 1
else:
    print 'in the else block of while'    
