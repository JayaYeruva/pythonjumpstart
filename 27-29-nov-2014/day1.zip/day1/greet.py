#!/usr/bin/env python

if 1==1:
    name = 'campy'
    city = 'bangalore'

print 'name :', name
print 'city :', city
