#!/usr/bin/env python

print 'amanda' + 
print 'kim',
print 'pam',
print 'anderson',
print 'trinity'

