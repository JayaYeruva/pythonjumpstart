__author__ = 'ravi'

l = [1, 12.12, 'almighty', 'perl']
l.append('pypi')
l.insert(0, 'cpan')

print l
