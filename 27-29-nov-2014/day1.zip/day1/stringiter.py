__author__ = 'ravi'
s = 'aeiou'

for i in s:
    print "{} : {}".format(i, ord(i))

