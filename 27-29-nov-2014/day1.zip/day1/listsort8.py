__author__ = 'ravi'

l = [12, '1alpine', 'bruce', 33, 'peter',
        '1', 12.12, 'almighty', 'perl', 17]

#l.sort(reverse=True)
#for i in reversed(l):

for i in sorted(l):
    print i
