__author__ = 'ravi'

l = [1, 12.12, 'almighty', 'perl']
val = l.pop(2)

del l[0]

print val
print l
