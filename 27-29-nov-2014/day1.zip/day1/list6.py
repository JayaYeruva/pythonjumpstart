__author__ = 'ravi'

l = [12, 1, 12.12, 'almighty', 'perl', 17]

for item in l[-3:]:
    print item
