__author__ = 'ravi'

s = 'the\tperl\nand\tthe python\tstring'
print s
print
#below one is the syntax for the raw string
s = r'the\tperl\nand\tthe python\tstring'
print s


s = u'the\tperl\nand\tthe python\tstring'
print s
