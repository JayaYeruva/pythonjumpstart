__author__ = 'ravi'

l = ['alpine', 'bruce', 'peter', 'almighty', 'perl']
temp = []

for i in l:
    temp.append(i.upper())

print temp

