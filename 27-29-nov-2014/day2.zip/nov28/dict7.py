info = {'hostname' : 'ws1', 'domain':'rootcap.in',
            'app':'mysql server', 'platform':'linux2'}


for k in info:
    print "[{}] -> {}".format(k, info.get(k))

print;print    
for k in sorted(info.keys()):
    print "[{}] -> {}".format(k, info.get(k))
