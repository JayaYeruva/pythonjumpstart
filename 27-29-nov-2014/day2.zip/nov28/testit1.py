#!/usr/bin/env python

names = ['pam', 'tim', 'jim', 'sam']
age = [3, 2, 4, 3]
gender = ['female', 'male', 'male', 'male']

for n, a, g in  zip(names, age, gender):
    print "{:>10} {:>5} {:>8}".format(n, a, g)
