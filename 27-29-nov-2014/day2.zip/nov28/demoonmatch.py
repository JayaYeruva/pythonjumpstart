__author__ = 'ravi'
import re

s = 'the pErL and the python script'

m = re.match('perl', s, re.I)

if m:
    print "got a match :)"
else:
    print "fails to match :("
