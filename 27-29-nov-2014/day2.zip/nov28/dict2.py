info = {'hostname' : 'ws1', 'domain':'rootcap.in',
            'app':'mysql server'}

print len(info)
print info
print type(info)

