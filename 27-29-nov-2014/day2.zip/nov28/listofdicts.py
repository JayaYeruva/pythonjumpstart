__author__ = 'ravi'
from pprint import pprint
#heading = ['login']

with open('passwd') as fp:
    heading = fp.readline().rstrip().split(':')

    content = [dict(zip(heading, l.rstrip().split(':')))
        for l in fp]

content.sort(key=lambda r: r['login'])
pprint(content)
