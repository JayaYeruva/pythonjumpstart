#!/usr/bin/env python
from sys import argv
import fileinput
import re

def usage():
    print "usage:"
    print "{} pattern filenames".format(argv[0])
    exit(1)

if len(argv) ==  1:
    usage()
        
pattern = argv.pop(1)

for l in fileinput.input():
    if re.search(pattern, l, re.I):
        print l.rstrip()
