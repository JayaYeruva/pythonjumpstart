info = {'hostname' : 'ws1', 'domain':'rootcap.in',
            'app':'mysql server', 'platform':'linux2'}

val = info.pop('app')

del info['domain']

print val
print info


