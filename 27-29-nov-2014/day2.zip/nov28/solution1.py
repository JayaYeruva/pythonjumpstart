__author__ = 'ravi'

from decimal import Decimal as D
a = 0.1
b = 0.3

print D(str(a)) + D(str(a)) + D(str(a)) - D(str(b))
