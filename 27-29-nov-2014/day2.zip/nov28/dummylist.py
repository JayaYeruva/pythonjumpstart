#!/usr/bin/env python

names = ['pam', 'tim', 'jim', 'sam']

t1 = names + names
t2 = names * 2

print t1

uniq = []
for i in t1:
    if i not in uniq:
        uniq.append(i)

print uniq        

