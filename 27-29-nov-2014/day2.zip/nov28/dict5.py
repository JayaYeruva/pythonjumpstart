info = {'hostname' : 'ws1', 'domain':'rootcap.in',
            'app':'mysql server', 'platform':'linux2'}


print info['hostname']
print info['domain']
print info.get('app')
print info.get('apps')
print info.get('apps', 'unknown')

