info = {'hostname' : 'ws1', 'domain':'rootcap.in',
            'app':'mysql server'}

if info.has_key('app'):
    info['app'] = 'apache2'


print info

'ravi.goglobium@gmail.com'


