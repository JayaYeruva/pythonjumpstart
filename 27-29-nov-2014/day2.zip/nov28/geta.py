#!/usr/bin/env python

import urllib2
import re

#response = urllib2.urlopen('http://www.hdfcbank.com/')
response = urllib2.urlopen('http://www.irctc.co.in/')
content = response.read()

#pattern = '<a href="(http://[a-zA-Z0-9]+)" .*?</a>'
pattern = '<a .*?</a>'

for m in re.finditer(pattern, content, re.I):
    atag =  m.group()
    extracthref = 'href="(http://.*)"'
    href = re.search(extracthref, atag, re.I)
    if href:
        print href.groups()


