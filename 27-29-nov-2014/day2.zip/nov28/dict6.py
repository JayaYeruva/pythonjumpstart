info = {'hostname' : 'ws1', 'domain':'rootcap.in',
            'app':'mysql server', 'platform':'linux2'}


print info.keys(); print 
print info.values(); print

print info.items()
