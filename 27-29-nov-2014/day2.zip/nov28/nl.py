import fileinput

for l in fileinput.input():
    print "{:>6}  {}".format(fileinput.lineno(), l.rstrip())
