#!/usr/bin/env python
from sys import argv
import fileinput
import re

pattern = argv.pop(1)

for l in fileinput.input():
    if re.search(pattern, l, re.I):
        print l.rstrip()
