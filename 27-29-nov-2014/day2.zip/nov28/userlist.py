__author__ = 'ravi'

ul = sorted([l.split(':')[0].title()\
             for l in open('/etc/passwd') if l.startswith('a')])

from pprint import pprint
pprint(ul)
