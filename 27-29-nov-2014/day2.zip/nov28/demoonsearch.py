__author__ = 'ravi'
import re

s = 'the pErL and the python script'

m = re.search('perl', s, re.I)

if m:
    print "got a match :)"
    print "matched : ", m.group()
    print m.start()
    print m.end()
    print m.span()
else:
    print "fails to match :("
