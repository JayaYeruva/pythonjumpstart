#!/usr/bin/env python

names = ['pam', 'tim', 'jim', 'sam']

def tagit(name):
    return "<name>{}</name>".format(name)

print map(tagit, names)
