__author__ = 'ravi'

nth = 3
count = 1
with open('/etc/passwd') as fp:
    while True:
        l = fp.readline()
        if count == nth:
            print l.rstrip()
            break
        count += 1


'''
for line in open('/etc/passwd'):
    if count == nth:
        print line.rstrip()
        break
    count += 1
'''