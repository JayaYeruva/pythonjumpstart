__author__ = 'ravi'
from sys import argv
wc = {}

with open(argv[1]) as fp:
    for line in fp:
        for word in line.rstrip('\n').split(' '):
            wc[word] = wc.get(word, 0) + 1


from pprint import pprint
pprint(wc)
