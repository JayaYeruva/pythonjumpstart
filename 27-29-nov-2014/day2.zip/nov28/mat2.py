__author__ = 'ravi'
mat = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]

#print mat[0]
#print mat[1]

#print [r[1] for r in mat]

print [col for row in mat for col in row if col%2 ]
