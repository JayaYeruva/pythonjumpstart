#!/usr/bin/env python

names = ['pam', 'tim', 'jim', 'sam']

t1 = names + names

print list(set(t1))
