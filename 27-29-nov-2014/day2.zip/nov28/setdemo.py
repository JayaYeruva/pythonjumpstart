from pprint import pprint 

user = { l.split(':')[0] for l in open('/etc/passwd')}
group = { l.split(':')[0] for l in open('/etc/group')}

uwg = user.intersection(group)
uwog = user - group
gwou = group - user

pprint(gwou)
