
from pprint import pprint

content = [l.rstrip().split(':') for l in open('/etc/passwd')]

content.sort( key = lambda row: int(row[2]), reverse=True )

pprint(content)

#for item in content:
#    print "{:>32}:{}".format(item[0], item[-1])
