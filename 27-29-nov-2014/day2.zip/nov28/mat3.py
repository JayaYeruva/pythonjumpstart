__author__ = 'ravi'
mat = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]

print [[row[i] for row in mat] for i in range(len(mat))]

