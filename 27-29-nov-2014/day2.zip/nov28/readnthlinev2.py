import fileinput

for l in fileinput.input():
    if fileinput.lineno() == 3:
        print l.rstrip(); break
