info = {}

print len(info)
print info
print type(info)

