def safe_float(obj):
    try:
         retval = float(obj)
        # n = 1/0
    except ValueError:
        retval = 'could not convert non-number to float'
    except TypeError:
        retval = 'object type cannot be converted to float'
    except Exception:
        retval = 'something gone wrong !!!!'
    return retval


print safe_float(12.12)
