import sys

try :
        raise ValueError, "Got an error"
except :
        if sys.exc_type == ValueError :
               print "Value Error" , sys.exc_type
               print sys.exc_info()[1]
        else :
               print "Something else"
