def safe_float(obj):
    retval = float(obj)
    return retval

#print safe_float('Spanish Inquisition')
try:
   #safe_float([])
   print safe_float('ravi')
   print safe_float(1.6)
   print safe_float(932)
   l=[0]
   print l[1]
except (ValueError, TypeError), e:
        #retval = 'argument must be a number or numeric string'
 	#pass
	print "this is an exception value & type " + str(e) 
except ZeroDivisionError, e:
	print "ZeroDivisionError" + e
finally:
   print "finally executes in any way"
