#!/usr/bin/env string

class MyExec (Exception):
    def disp(self):    
        return "My exception string"
try:
    raise MyExec
except MyExec,  e :
    print 'caught :' + e.disp()
