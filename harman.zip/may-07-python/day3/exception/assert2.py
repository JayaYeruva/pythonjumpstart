def f(x):
    assert x > 0 , 'x must be positive'
    return x ** 2


try:
    f(-1)
except AssertionError, args:
    print '%s: %s' % (args.__class__.__name__, args)
