import sys
#f = open('blah', 'r')
try:
    f = open('blah', 'r')
except Exception, e:
    print 'could not open file:', e
#    sys.exit(1)  
#print float(12345)
#print float('12345')
#print float('123.45e67')

def safe_float(obj):
     try:
         retval = float(obj)
     except ValueError:
          retval = 'could not convert non-number to float'
     except TypeError:
          retval = 'invalid type to convert to float'
     except Exception:
          return  'server error'	  
     return retval

print safe_float('12.34')
print safe_float('bad input')
print safe_float({'a': 'Dict'})
