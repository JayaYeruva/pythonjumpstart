try:
    # some python statements
except [ExceptionName]:
   # some error handling
finally:
   # do something when all is done.

Standard Python Error Types

Exception             
StandardError         
ArithmeticError       
LookupError           
AssertionError        
AttributeError        
EOFError              
EnvironmentError      
FloatingPointError    
GeneratorExit         
IOError               
ImportError           
IndexError            
KeyError              
KeyboardInterrupt     
MemoryError           
NameError             
NotImplementedError   
OsError               
OverflowError         
ReferenceError        
StopIteration         
SyntaxError           
SystemError           
TypeError             
UnboundLocalError     
ValueError            
WindowsError          
ZeroDivisionError
