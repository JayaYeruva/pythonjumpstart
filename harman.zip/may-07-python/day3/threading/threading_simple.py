#!/usr/bin/env python
# encoding: utf-8
#

#
"""Creating and waiting for a thread.
"""
#end_pymotw_header

import threading
import random
import time

def worker():
    """thread worker function"""
    time.sleep(random.randint(1,5))
    print 'Worker'

threads = []
for i in range(5):
    t = threading.Thread(target=worker)
    threads.append(t)
    t.start()  # starts the excution of the threads 
    t.join()
print "main thread"
