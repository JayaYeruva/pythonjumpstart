#!/bin/env python 
import urllib
import urllib2
import tempfile
import sys
import threading
import logging

# global config 
split_file_list = []
fp = None
flag = 1
t_list = []
logging.basicConfig(level=logging.DEBUG, format="%(asctime)s %(threadName)s %(message)s")

def write2file():
    data = fp.read(1042)
    global flag
    if not data: 
	flag = 0
        return
    temp = tempfile.mktemp()


    fw = open(temp, 'w')
    fw.write(data)
    logging.debug(": "+temp+" written")
    fw.close()
    split_file_list.append(temp) 	


def url_get(url):
    global fp
    fp =  urllib2.urlopen(url)
    global t_list
    while 1 :
        t = threading.Thread(target=write2file)
	if flag == 0:  
	     break
	t_list.append(t)
        t.start()
        
    return split_file_list


for t in t_list:
    t.join()


print url_get(sys.argv[1])
if __name__ == '__main__':
    url_get(sys.argv[1])





