#!/bin/env python 
import tempfile
def filesplit(name):
    with open(name) as f :
	split_file_list = []
	while 1 :
            temp = tempfile.mktemp()
            fw = open(temp, 'w')
	    data = f.read(1024)
	    if not data:  
		break
            fw.write(data)
            fw.close()
            split_file_list.append(temp)
    return split_file_list

def joinfile(namelist, file_name):
    for fname in namelist:
	with open(file_name, 'a') as fa:
             fp = open(fname)
             fa.write(fp.read())
	     fp.close()	 

if __name__ == '__main__':
    fl =  filesplit('passwd') 
    joinfile(fl, 'pass22')
	 

	     
