#!/usr/bin/env python
# encoding: utf-8
#
#
"""Passing arguments to threads when they are created
"""
#end_pymotw_header

import threading
import random
import time
def worker(num):
    """thread worker function"""
    time.sleep(random.randint(1,10))
    print 'Worker: %s' % num
    return

threads = []
for i in range(5):
    t = threading.Thread(target=worker, args=(i,))
    threads.append(t)


for t in threads:    
     t.start()
print 'a sample content for the main'
