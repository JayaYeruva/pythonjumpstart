import Blogger

class TestBlogger:
    
    def setup_method(self, method):
        print "in setup_method"
        self.blogger = Blogger.get_blog()
       
    def test_get_feed_title(self):
        title = "fitnessetesting"
        assert self.blogger.get_title() == title

    def test_get_feed_posting_url(self):
        posting_url = "http://www.blogger.com/atom/9276918"
        assert self.blogger.get_feed_posting_url() == posting_url

    def test_get_feed_posting_host(self):
        posting_host = "www.blogger.com"
        assert self.blogger.get_feed_posting_host() == posting_host
        
    def test_post_new_entry(self):
        init_num_entries = self.blogger.get_num_entries()
        title = "testPostNewEntry"
        content = "testPostNewEntry"
        assert self.blogger.post_new_entry(title, content) == True
        assert self.blogger.get_num_entries() == init_num_entries+1
        # Entries are ordered most-recent first
        # Newest entry should be first
        assert title == self.blogger.get_nth_entry_title(1)
        assert content == self.blogger.get_nth_entry_content_strip_html(1)

    def test_delete_all_entries(self):
        self.blogger.delete_all_entries()
        assert self.blogger.get_num_entries() == 0
