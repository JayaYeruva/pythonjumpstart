import doctest
doctest.testfile("testfile_blogger")
