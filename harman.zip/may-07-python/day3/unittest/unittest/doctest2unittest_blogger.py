import unittest
import doctest

suite = unittest.TestSuite()
suite.addTest(doctest.DocFileSuite("testfile_blogger"))
unittest.TextTestRunner().run(suite)
