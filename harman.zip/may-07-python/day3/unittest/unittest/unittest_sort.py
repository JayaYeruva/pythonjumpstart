import unittest

class TestSort(unittest.TestCase):

    def setUp(self):
        self.alist = [5, 2, 3, 1, 4]

    def test_ascending_sort(self):
        self.alist.sort()
        self.assertEqual(self.alist, [1, 2, 3, 4, 5])

    def test_custom_sort(self):
        def int_compare(x, y):
            x = int(x)
            y = int(y)
            return x - y
        self.alist.sort(int_compare)
        self.assertEqual(self.alist, [1, 2, 3, 4, 5])

        b = ["1", "2", "10", "20", "100"]
        b.sort()
        self.assertEqual(b, ['1', '10', '100', '2', '20'])
        b.sort(int_compare)
        self.assertEqual(b, ['1', '2', '10', '20', '100'])

    def test_sort_reverse(self):
        self.alist.sort()
        self.alist.reverse()
        self.assertEqual(self.alist, [5, 4, 3, 2, 1])

    def test_sort_exception(self):
        try:
            self.alist.sort(int_compare)
        except NameError:
            pass
        else:
            fail("Expected a NameError")
        self.assertRaises(ValueError, self.alist.remove, 6)


def suite():
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(TestSort))
    return suite

if __name__ == "__main__":
    unittest.main()
    #unittest.TextTestRunner(verbosity=2).run(suite())
