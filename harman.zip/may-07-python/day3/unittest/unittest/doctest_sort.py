def test_ascending_sort():
    """
    >>> a = [5, 2, 3, 1, 4]
    >>> a.sort()
    >>> a
    [1, 2, 3, 4, 5]
    """

def test_custom_sort():
    """
    >>> def int_compare(x, y):
    ...     x = int(x)
    ...     y = int(y)
    ...     return x - y
    ...
    >>> a = [5, 2, 3, 1, 4]
    >>> a.sort(int_compare)
    >>> print a
    [1, 2, 3, 4, 5]
    >>> b = ["1", "2", "10", "20", "100"]
    >>> b.sort()
    >>> b
    ['1', '10', '100', '2', '20']
    >>> b.sort(int_compare)
    >>> b
    ['1', '2', '10', '20', '100']
    """

def test_sort_reverse():
    """
    >>> a = [5, 2, 3, 1, 4]
    >>> a.sort()
    >>> a.reverse()
    >>> a
    [5, 4, 3, 2, 1]
    """

def test_sort_exception():
    """
    >>> a = [5, 2, 3, 1, 4]
    >>> a.sort(int_compare)
    Traceback (most recent call last):
      File "<stdin>", line 1, in ?
    NameError: name 'int_compare' is not defined
    """

if __name__ == "__main__":
    import doctest
    doctest.testmod()
