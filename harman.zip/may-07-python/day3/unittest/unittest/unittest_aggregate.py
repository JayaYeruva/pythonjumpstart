import unittest
import unittest_sort
import unittest_blogger

suite1 = unittest_sort.suite()
suite2 = unittest_blogger.suite()

suite = unittest.TestSuite()
suite.addTest(suite1)
suite.addTest(suite2)
unittest.TextTestRunner(verbosity=2).run(suite)
