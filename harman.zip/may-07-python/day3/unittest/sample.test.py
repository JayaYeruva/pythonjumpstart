import unittest
    
class IntegerArithmenticTestCase(unittest.TestCase):
    def testAdd(self):  ## test method names begin 'test*'
        self.assertEqual((1 + 2), 3)
        self.assertEqual(0 + 1, 1)
    def testMultiply(self):
        self.assertEqual((0 * 10), 10)
        self.assertEqual((5 * 8), 40)
    def non_test():
        pass
    
if __name__ == '__main__':
    try:
        #print (10/0)
        unittest.main()
    except Exception as e:
        print e
