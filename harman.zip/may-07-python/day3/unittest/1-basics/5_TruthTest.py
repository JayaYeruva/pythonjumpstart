import unittest

class TruthTest(unittest.TestCase):

    def testFailUnlessFalse(self):
        self.failUnless(False)

    def testFailUnless(self):
        self.failUnless(True)

    def testAssertTrue(self):
        self.assertTrue(True)

    def testFailIfTrue(self):
        self.failIf(True)

    def testFailIf(self):
        self.failIf(False)

    def testAssertFalse(self):
        self.assertFalse(False)

if __name__ == '__main__':
    unittest.main()
