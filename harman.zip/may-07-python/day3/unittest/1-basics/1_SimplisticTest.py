import unittest

class SimplisticTest(unittest.TestCase):

    def test(self):
        self.failUnless(3==3)

if __name__ == '__main__':
    unittest.main()
