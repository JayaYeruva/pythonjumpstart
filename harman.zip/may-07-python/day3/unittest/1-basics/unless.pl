#!/usr/bin/perl 
#===============================================================================
#
#         FILE: unless.pl
#
#        USAGE: ./unless.pl  
#
#  DESCRIPTION: 
#
#      OPTIONS: ---
# REQUIREMENTS: ---
#         BUGS: ---
#        NOTES: ---
#       AUTHOR: YOUR NAME (), 
#      COMPANY: 
#      VERSION: 1.0
#      CREATED: 04/20/2012 05:07:17 PM
#     REVISION: ---
#===============================================================================

use strict;
use warnings;
my $n = 2;
unless($n==5) {
  print "above condition becomes true";
}
