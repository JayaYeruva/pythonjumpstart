import unittest
#import copyfile

class EqualityTest(unittest.TestCase):

    def testEqual(self):
        sou = '/etc/passwd'
        dest = 'passwd'
        stat = 0 #copy(sou, dest)
        self.assertEqual(0, stat)

    def testNotEqual(self):
        self.failIfEqual(2, 3-2)

if __name__ == '__main__':
    unittest.main()
