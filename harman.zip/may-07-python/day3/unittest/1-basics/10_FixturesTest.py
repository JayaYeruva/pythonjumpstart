"""
    Fixtures are resources needed by a test. 
    For example, if you are writing several tests for the same class, 
        those tests all need an instance of that class to use for testing. 
    Other test fixtures include database connections and temporary files.

    To configure the fixtures, override setUp(). 

    To clean up, override tearDown(). 
"""

import unittest

class FixturesTest(unittest.TestCase):

    def setUp(self):
        print 'In setUp()'
        self.fixture = range(1, 10)

    def tearDown(self):
        print 'In tearDown()'
        del self.fixture

    def test(self):
        print 'in test()'
        self.failUnlessEqual(self.fixture, range(1, 10))

if __name__ == '__main__':
    unittest.main()
