import simple

print dir(simple)
