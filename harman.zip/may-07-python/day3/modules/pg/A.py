# A.py

import B
