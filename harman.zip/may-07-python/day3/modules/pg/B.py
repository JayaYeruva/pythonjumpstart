# B.py

def function_b():
    print 'Hello from function_b'
