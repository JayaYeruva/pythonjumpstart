# __init__.py

# Expose definitions from modules in this package.
from module1 import class1
from module2 import class2

__all__=['class1']
