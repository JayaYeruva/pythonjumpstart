# module1.py

class class1:
    def __init__(self):
        self.description = 'class #1'
    def show(self):
        print self.description
