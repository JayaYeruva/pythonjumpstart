# module2.py

class class2:
    def __init__(self):
        self.description = 'class #2'
    def show(self):
        print self.description
