#!/usr/bin/env python

"""
    You need to enable interactive mode,
    stay connect to ssh, and able to send my input myself?
"""


import pexpect
import struct, fcntl, os, sys, signal

ssh_newkey = 'Are you sure you want to continue connecting'
p=pexpect.spawn('ssh training@localhost ')
i=p.expect([ssh_newkey,'password:',pexpect.EOF,pexpect.TIMEOUT],1)
if i==0:
    print "I say yes"
    p.sendline('yes')
    i=p.expect([ssh_newkey,'password:',pexpect.EOF])
if i==1:
    print "I give password",
    p.sendline("training")
elif i==2:
    print "I either got key or connection timeout"
    pass
elif i==3: #timeout
    pass
p.sendline("\r")

try:
    p.interact()
    print "am testing this"
    sys.exit(0)
except:
    sys.exit(1)
