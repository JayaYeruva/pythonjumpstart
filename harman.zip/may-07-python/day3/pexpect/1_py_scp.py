import pexpect

child = pexpect.spawn('scp /etc/passwd training@localhost:~')
child.expect ('training@localhost\'s password:')
child.sendline("training")
child.expect(pexpect.EOF)
