#!/bin/env python 

import sys
sys.stdout.write( sys.stdin.read())

