#!/bin/env python 

class Dummy(object):
   """a sample dummy class"""
   pass

print Dummy.__dict__
print Dummy.__module__
print Dummy.__doc__
print Dummy.__name__
