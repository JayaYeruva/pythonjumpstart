#!/usr/bin/env python
class FooBar: 
    def __init__(self): 
        self.somevar = 42 

f = FooBar() 
print f.somevar
