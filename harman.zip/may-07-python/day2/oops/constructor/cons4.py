#!/usr/bin/env python

""" method over ridding """
class Base:
    def __init__(self, x):
        print "super.__init__ " * x

class Sub(Base):
    def __init__(self, x, y):
        #Base.__init__(self, x)
	pass


s = Sub(5,.001)

