#!/usr/bin/env python
class grocery:
    def __init__(self, name, quantity=1):
        self.name = name
        self.quantity = quantity

items = {}
items['A'] = grocery('A')
items['B'] = grocery('B',2)

for item in items.keys():
  print "Grocery : ", items[item].name,
  print "\tQuantity: ", items[item].quantity

