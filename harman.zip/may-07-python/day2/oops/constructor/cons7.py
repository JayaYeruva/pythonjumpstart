class A(object) :
    def __init__(self) :
        self.a = 1

    def multiply(self, v) :
        print "Mul. in A"
        return self.a * v

class B(object) :
    def __init__(self) :
        self.b = 2

    def multiply(self, v) :
        print "Mul. in B"
        return self.a * v

    def save(self) :
        print "Saving Object.."
        for a in vars(self) :
            print "Saving " + a

class C(B, A) :
    def __init__(self) :
        A.__init__(self)
        B.__init__(self)

    def multiply_and_save(self, v) :
        super(C,self).multiply(v)
        super(C,self).save()

c = C()
c.multiply_and_save(3)
exit()

class Save(object) :
    def __init__(self) :
        self.filename = "save.txt"

    def save(self) :
        fH = open(self.filename, "w")
        for a in vars(self) :
            fH.write( a )
            fH.write( "=" )
            fH.write( str(self.__dict__[a]) )
            fH.write("\n")
        fH.close()


class D(Save) :
    def __init__(self) :
        Save.__init__(self)
        self.name = "D"
        self.value = 3
        self.color = "blue"

    def __del__(self) :
        super(D, self).save()

d = D()
del d
