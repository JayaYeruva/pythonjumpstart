class Bird:
   def __init__(self):
      self.hungry = 1
      self.sound = "pow pow"

   def eat(self):
     if self.hungry:
        print 'Aaaah...'
        self.hungry = 0
     else:
        print 'No, thanks!' 

   def sing(self):
        #self.sound = 1   
	print "with high pitch..." + self.sound

class SongBird(Bird): 
    def __init__(self): 
        Bird.__init__(self)
        self.sound = 'Squawk!' 
    
    def sing(self):
        Bird.sing(self) 
        print self.sound 

sb = SongBird() 
sb.sing() 
#exit(1)
sb.eat()
sb.eat()
exit(1)
b = Bird()
b.sing()







