class Bird(object):
    def __init__(self):
       self.hungry = 1
    def eat(self):
       if self.hungry == 1: 
          print 'hungry...'
          self.hungry = 0
       else: 
          print 'No, thanks!'

class SongBird(Bird):
    def __init__(self):
        super(SongBird, self).__init__()   #calling the base class constructor
        self.sound = 'Squawk!'
    def sing(self):
        print self.sound

sb = SongBird() 
sb.sing() 
sb.eat() 
sb.eat()
