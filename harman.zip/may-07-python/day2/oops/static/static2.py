class Employee:
   numberOfEmployees = 0 
   maxEmployees = 10     

   def isCrowded():
      return Employee.numberOfEmployees > Employee.maxEmployees

   isC = staticmethod(isCrowded )  # make a function to static
   
   def __init__( self, firstName, lastName ):
      self.first = firstName
      self.last = lastName
      Employee.numberOfEmployees += 1

   def __del__( self ):
      Employee.numberOfEmployees -= 1      

   def __str__( self ):
      return "%s %s" % ( self.first, self.last )


answers = [ "No", "Yes" ] 
employeeList = []         

print answers[ Employee.isC() ]

for i in range( 11 ):
   employeeList.append( Employee( "John", "Doe" + str( i ) ) )

   print "Employees are crowded?", i, ' ',
   print answers[ employeeList[ i ].isC() ]

del employeeList[ 0 ]

print "Employees are crowded?", answers[ Employee.isC() ]

