#!/usr/bin/env python
class MyClass:
    @staticmethod
    def smeth():
        print 'This is a static method'

    @classmethod
    def cmeth(self):
        print 'This is a class method of', self

MyClass.smeth()

m = MyClass() 
m.cmeth()


