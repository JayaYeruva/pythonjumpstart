#!/usr/bin/env python

class NumStr(object):
    def __init__(self, num=0, string=''):
        self.__num = num
        self.__string = string

    def __str__(self):        
        return '[%d :: %r]' % (self.__num, self.__string)
    __repr__ = __str__

    def __add__(self, other):     # define for s+o
        if isinstance(other, NumStr):
            return self.__class__(self.__num + other.__num, self.__string + other.__string)
        else:
            raise TypeError, 'Illegal argument type for built-in operation'

    def __mul__(self, num):       # define for  o * n
        if isinstance(num, int):
            return self.__class__(self.__num * num, self.__string * num)
        else:
           raise TypeError, 'Illegal argument type for built-in operation'

    def __nonzero__(self):        # False if both are
        return self.__num  or len(self.__string)


    def __cmp__(self, other):     # define for cmp()
        return self.__norm_cval(cmp(self.__num, other.__num)) + self.__norm_cval(cmp(self.__string, other.__string))

          

a = NumStr(3, 'foo')
b = NumStr(3, 'bar')
c = NumStr(2, 'foo')
d = NumStr()
e = NumStr(string='boo')
f = NumStr(1)
print a + b
print a * 3 
exit(1)
#print a * 3
#print b + e
#print e + b
if d: 'not false'     # also bool(d)
if e: 'not false'     # also bool(e)
#print cmp(a,b)
#print cmp(a,c)
#print cmp(a,a)
