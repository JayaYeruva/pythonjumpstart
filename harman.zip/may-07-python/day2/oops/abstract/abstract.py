#!/usr/bin/env python
#abstract class
class Employee:
   def __init__( self, first, last ):
      if self.__class__ == Employee:
         raise NotImplementedError, "Cannot create object of class Employee"
      self.firstName = first
      self.lastName = last

   def __str__( self ): # to overload the print statement the object. asa __repr__
      return "%s %s" % ( self.firstName, self.lastName )

   def _isValid( self, value ):
      if value < 0:
         raise ValueError, "Attribute value (%s) must be positive" % value
      else:
         return value

   def earnings( self ):
      raise NotImplementedError, "Cannot call abstract method"

class Boss( Employee ):
   def __init__( self, first, last, salary ):
      Employee.__init__( self, first, last )
      self.weeklySalary = self._isValid( float( salary ) )

   def earnings( self ):
      return self.weeklySalary

   def __str__( self ):
      return "%20s: %s" % ( "Boss", Employee.__str__( self ) )

class Developer( Employee ):
   def __init__( self, first, last, salary, commission, quantity ):
      Employee.__init__( self, first, last )
      self.salary = self._isValid( float( salary ) )
      self.commission = self._isValid( float( commission ) )
      self.quantity = self._isValid( quantity )

   def earnings( self ):
      return self.salary + self.commission * self.quantity

   def __str__( self ):
      return "%20s: %s" % ( "Commission Worker", Employee.__str__( self ) )

class Tester( Employee ):
   def __init__( self, first, last, wage, quantity ):
      Employee.__init__( self, first, last )
      self.wagePerPiece = self._isValid( float( wage ) )
      self.quantity = self._isValid( quantity )

   def earnings( self ):
      return self.quantity * self.wagePerPiece

   def __str__( self ):
      return "%20s: %s" % ( "Piece Worker", Employee.__str__( self) )

class Programmer( Employee ):
   def __init__( self, first, last, wage, hours ):
      Employee.__init__( self, first, last )
      self.wage = self._isValid( float( wage ) )
      self.hours = self._isValid( float( hours ) )

   def earnings( self ):
      if self.hours <= 40:
         return self.wage * self.hours
      else:
         return 40 * self.wage + ( self.hours - 40 ) * self.wage * 1.5

   def __str__( self ):
      return "%20s: %s" % ( "Hourly Worker",Employee.__str__( self ) )

e = Employee('Sivam', 'krish')
# main program
employees = [ Boss( "patric", "norton", 8.00 ),
              Developer( "james", "cameron", 2.0, 3.0, 150 ),
              Tester( "jessica", "mella", 2.5, 200 ),
              Programmer( "sam", "jackson", 13.75, 40 ) ]

for employee in employees:
   print "%s earned $%.2f" % ( employee, employee.earnings() )














