#!/usr/bin/env python
class C1(object):
    def __init__(self, who):    
        self.__name = who  #__name private member

    def __disp(self):
        print "Name: " + self.__name
    def display(self):
	self.__disp();


I1 = C1('bob')                  

I1.display()
