class PrivateClass:
   def __init__( self ):
      self.publicData = "public"      # public data member
      self.__privateData = "private"  # private data member

   def __display(self):
      """ private method """	
      return self.__privateData	

   def publicm(self):
      return self.__display()


obj = PrivateClass()
print obj.publicData
print obj.publicm()
#print obj.__privateData
