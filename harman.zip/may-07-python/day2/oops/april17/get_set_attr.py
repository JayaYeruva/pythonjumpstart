#!/bin/env python 

class TestAttr:
    def __init__(self):
	pass

    def __setattr__(self, attr, val):
	self.__dict__[attr] = val
         
    def __getattr__(self, attr ):
	return self.__dict__[attr]

t = TestAttr()

t.no = 1001
t.name = 'peter'
t.gender = 'male'

print t.no
print t.name
print t.gender

