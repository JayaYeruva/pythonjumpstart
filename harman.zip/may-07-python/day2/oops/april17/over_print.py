#!/bin/env python 

class Over:
   def __init__(self, data):
	self.data = data

   def __repr__(self):
   	#return str(self.data)
        return self.__str__()

   def __str__(self):
	return " string : %s " % str(self.data)
#o1 = Over('catch me if you can')
o1 = Over(1000)
print str(o1)
print repr(o1)
print o1
