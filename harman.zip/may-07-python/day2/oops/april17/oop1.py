#!/bin/env python 

class TestClass:
    """ coding standard 
     structured   _ notation
     get_system_details()
     
     OO
     camel case
     class : DynamicBuildingBlock
     method :  getSystemDetail()  
     attr: sysCpuInfo  
    """
    pass 
 

# instance for the above class
t = TestClass()
print t
print type(t)
print dir(t)



