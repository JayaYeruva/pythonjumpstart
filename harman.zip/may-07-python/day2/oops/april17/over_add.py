#!/bin/env python 

class Rectangle:
   def  __init__(self, l, b):
	self.l = l
        self.b = b

   def __add__(self, r2):
	s2r = Rectangle(0,0)
	s2r.l = self.l + r2.l
	s2r.b = self.b + r2.b
	return s2r
   
   def __repr__(self):
	return "(%d, %d)" %(self.l, self.b)

r1 = Rectangle(4,2)
r2 = Rectangle(6,6)

print r1+r2

#(10, 8)

 
