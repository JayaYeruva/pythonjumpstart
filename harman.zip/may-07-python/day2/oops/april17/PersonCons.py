#!/bin/env python 

class Person(object):
    def __init__(self, name, age, height, gender):
	self.name = name
	self.age = age
	self.height = height
	self.gender = gender

    def getPersonDetails(self):
	print self.name
	print self.age
	print self.height
	print self.gender

    def setPersonDetails(self, name, age, height, gender):
	self.name = name
	self.age = age
	self.height = height
	self.gender = gender


p1 = Person('jack', '54', 153, 'male')
p1.getPersonDetails()

p2 = Person('jackson', '154', 2153, 'female')
p2.getPersonDetails()

print p2.height
print p1.height





