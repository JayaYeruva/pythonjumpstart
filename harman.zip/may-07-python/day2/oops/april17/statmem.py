#!/bin/env python 

class Population:
    pCount = 0  # static variable 
    MAX = 10
    def checkPopulation():
	""" a static method  definition"""
	if Population.pCount == 10:
	     print "over population"
	     #exit(1)
	else:
	     Population.pCount += 1; 	
	     print "Population Count : %d" % Population.pCount;

    checkPopulation = staticmethod(checkPopulation) #static method 

    def __init__(self):
	Population.checkPopulation()
        self.id = Population.pCount
    
    def getId(self):
         print "Person id : %d" % self.id


popObj = []
for i in range(1,16):
    if Population.MAX != i: 
          popObj.append(Population())
    else:
          break
for o in popObj:
     o.getId()


        
