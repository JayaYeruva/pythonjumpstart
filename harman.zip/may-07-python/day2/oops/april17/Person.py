#!/bin/env python 

class Person:
    def __init__(self):
	self.name = None
        self.age = None
        self.height = None
	self.gender = None

    def getPersonDetails(self):
	print self.name
	print self.age
	print self.height
	print self.gender

    def setPersonDetails(self, name, age, height, gender):
	self.name = name
	self.age = age
	self.height = height
	self.gender = gender


p1 = Person()
p1.setPersonDetails('jack', '54', 153, 'male')
p1.getPersonDetails()

p2 = Person()
p2.setPersonDetails('jackson', '154', 2153, 'female')
p2.getPersonDetails()

print p2.height
print p1.height





