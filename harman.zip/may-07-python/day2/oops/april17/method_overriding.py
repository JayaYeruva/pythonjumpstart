#!/bin/env python 

class Report:
	def pprint(self):
	    return """-rw-rw-r-- 1 ravi ravi 159 Apr 17 11:00 access_spec
-rw-rw-r-- 1 ravi ravi 551 Apr 17 10:46 ClassDemo.py
-rw-rw-r-- 1 ravi ravi 346 Apr 17 10:19 oop1.py
		"""

class ReportXML(Report):
	def pprint(self):
		str = ''
		#str +=  "<?xml version='1'>"
		str += "<output>"
		str += Report.pprint(self)   #base call method
		str += "</output>"
		return str


r = ReportXML()
print r.pprint()
	
