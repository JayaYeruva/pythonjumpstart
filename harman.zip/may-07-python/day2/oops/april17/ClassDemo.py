#!/bin/env python 

class Person:
    def __init__(self):

        """ constructor
            a spl that get invoked automatically during the object creation 
            to initalize the members of the class ie the attr.
            to get resource for your functionality 

           method in a class, should have a self ref. for the current object. 
        """ 
        pass


    def getSelf(self):
        print "Self : ",id(self)



p1 = Person()
p2 = Person()

print "P1 : %ld " % id(p1)
p1.getSelf()
print "P2 : %ld " % id(p2)
p2.getSelf()
