class Demo:
    #def __repr__(self):
    def __str__(self):
        """will overload the behavior of the print statement """
	return "string representation of the object"

d = Demo()
print d
