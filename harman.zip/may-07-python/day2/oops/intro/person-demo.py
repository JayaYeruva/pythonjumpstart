import sys
sys.path.append('.')
import person

p = person.Person()
print dir(p)
print p.__doc__
