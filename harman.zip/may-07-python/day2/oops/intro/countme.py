#!/usr/bin/env python 

class Person:
    count = 0
    def __init__(self):
        Person.count += 1

o_p = []

for i in range(1,20):
    o_p.append(Person())
    if Person.count == 15:
        print "reached max population limit"
        exit(1)
    print "Population count : %d" % Person.count



