class Demo:
    def __init__(self, a, b):
        self.a = a
        self.b = b

    def __add__(self, o):
	return  Demo((self.a + o.a), (self.b+o.b))


    def __repr__(self):
	return str((self.a , self.b))


d1 = Demo(10, 20) 
d2 = Demo(110, 220)
print d1 + d2  
