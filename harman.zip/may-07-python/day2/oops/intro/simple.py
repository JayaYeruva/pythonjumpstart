class SimpleClass:

    def getName(self):
	return self.name
 
    def setName(self, name):
	self.name = name

d = SimpleClass()
d.setName('peter pan')
print d.getName();
