#!/bin/env python 

""" a person class  demonstration"""

class Person:
    """ Person class : desc about a person """

    def __init__(self):
        self.name = ''
        self.age=0
        self.gender = ''

    def setInfo(self, name, age, gender):
	self.name = name
	self.age = age
	self.gender = gender

    def getInfo(self):
	print self.name
	print self.age
	print self.gender

if Person.__module__ == '__main__':
    o = Person()
    o.setInfo('ram', '45', 'male')
    o.getInfo()




