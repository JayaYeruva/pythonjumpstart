#!/usr/bin/env python
class Person: 
    def setName(self, name):
        self.name = name 
    def getName(self):
        return self.name 
    def greet(self):
        print "Hello, world! I'm %s." % self.name

foo = Person()
bar = Person()
foo.setName('Allen')
bar.setName('Bob')
foo.greet()
bar.greet()
print foo.name 
bar.greet()
