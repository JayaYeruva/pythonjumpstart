#!/usr/bin/env python
class Date:
   daysPerMonth = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 ]

   def __init__( self, month, day, year ):
      if 0 < month <= 12:   
         self.month = month
      else:
         raise ValueError, "Invalid value for month: %d" % month

      if year >= 0:         
         self.year = year
      else:
         raise ValueError, "Invalid value for year: %y" % year
      
      self.day = self.checkDay( day )   

      #print "Date constructor:",
      #self.display()

   def __del__( self ):   #destructor
      print "Date object about to be destroyed:",
      self.display()

   def display( self ):
      print "%d/%d/%d" % ( self.month, self.day, self.year )

   def checkDay( self, testDay ):
      if 0 < testDay <= Date.daysPerMonth[ self.month ]:
         return testDay
      elif self.month == 2 and testDay == 29 and ( self.year % 400 == 0 or self.year % 100 != 0 and self.year % 4 == 0 ):
         return testDay
      else:
         print  "Invalid day: %d for month: %d" % ( testDay, self.month )

try:
    date = Date(02,37,2008);
    #print date.checkDay(17)
    date.display()
except (ValueError, TypeError), e:
    print e 












