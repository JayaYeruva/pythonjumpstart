#!/usr/bin/env python
class AddrBookEntry(object):           
    def __init__(self, nm, ph):          #constructor
        self.name = nm                 
        self.phone = ph                
        print 'Created instance for:', self.name, self.phone

    def updatePhone(self, newph):      
        self.phone = newph
        print 'Updated phone# for:', self.name


john = AddrBookEntry('A', '000-555-1212')
jane = AddrBookEntry('B', '111-555-1212')
#peter = AddrBookEntry()
print john
print john.name
print john.phone
exit(1)
print jane.name
print jane.phone
#print dir(AddrBookEntry)
#print dir(john)
john.updatePhone('111-555-1212')
print john.phone
