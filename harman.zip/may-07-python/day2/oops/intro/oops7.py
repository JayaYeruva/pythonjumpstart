# It has the following syntax: isinstance(obj1, obj2)

class C1(object): pass
class C2(object): pass

c1 = C1()
c2 = C2()

print isinstance(c1, C1)
print isinstance(c2, C1)
print isinstance(c1, C2)
print isinstance(c2, C2)
#print isinstance(C2, c2)
print isinstance(4, int)
print isinstance(4, str)
print isinstance('4', str)
