#!/usr/bin/env python
class MyClass:
    def talk(self, data):
	self.data = data
        print "an instance of class MyClass."
   
    def disp(self):
        print self.data 		

    def testit(s):
        print "without the reference to obj."

crit = MyClass()
crit.talk(1000)
crit.disp()
crit.testit()

d1 = MyClass()
d1.talk(4)
d1.disp()
