#!/usr/bin/env python

class PrintObject:
     pass
#    def __repr__(self):
#        return "print statement is overloaded"

p = PrintObject()

print p
