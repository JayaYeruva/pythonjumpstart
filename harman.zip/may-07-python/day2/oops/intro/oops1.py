#!/usr/bin/env python
# Special Class Attributes
# C.__name__      String name of class C
# C.__doc__      Documentation string for class C
# C.__bases__      Tuple of class C's parent classes
# C.__dict__      Attributes of C
# C.__module__  Module where C is defined (new in 1.5)
# C.__class__      Class of which C is an instance (new-style classes only)


class MyClass(object): 
    """a sample dummy class"""	
    pass

print MyClass.__name__
print MyClass.__doc__
print MyClass.__bases__
print MyClass.__dict__
print MyClass.__module__
