#!/bin/env python
import re
 
fm = open('master.dat')
fd = open('detail.dat')
flag = 1
orders = {}
for master in fm:
    if flag == 1:
	flag = 0
	continue
    master_rec = master.split(',')
    orders[master_rec[0]] = {
 			'client_code':	master_rec[1],
			'capturedby' : master_rec[2],
			'detail' : []
			}
    
    for detail in fd:
        if re.search('^'+master_rec[0], detail, re.I):
             detail_rec =  detail.split(',')
	     orders[master_rec[0]]['detail'].append({
			'line_no':detail_rec[1],
			'item_code':detail_rec[2],
			'quantity':detail_rec[3]
		})
	     
    fd.seek(0,0)

fm.close()
fd.close()

for or_no in orders.keys():
    lab = 1
    print "%s\t%s\t%s" % (or_no, 
			  orders[or_no]['client_code'],
			  orders[or_no]['capturedby'])

    for order in orders[or_no]['detail']:
	if lab == 1:
	    print "\t", "\t".join(order.keys())
            lab = 0 
	for or_key in order.keys():
	     print "\t"+order[or_key],




