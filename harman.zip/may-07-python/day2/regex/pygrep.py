#!/bin/env python 
""" python implementation of grep """
import sys
import re

#validating the args
if len(sys.argv)!=3 :
    print "Usage: %s %s %s" % (sys.argv[0], "pattern", "file-name")
    exit(1)

file = sys.argv[2];
fp = open(file);
for line in fp:
   if  re.search(r''+sys.argv[1], line, re.I):
	print line,

fp.close()
