#!/bin/env python 

import re
fp = open('log.dat')
for line in fp:
   print  re.sub(r'(\d{2})-(\d{2})-(\d{4})', r'\3-\2-\1', line),

fp.close()
