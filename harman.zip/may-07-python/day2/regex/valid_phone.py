#!/bin/env python 

import re
fp = open('phonenum')
for line in fp:
   #if re.search(r'[0-9]{3}[\ \-]?[0-9]{3}[\ \-]?[0-9]{4}', line ):
   if re.search(r'\d{3}[\ \-]?\d{3}[\ \-]?\d{4}', line ):
	print line,

fp.close()
