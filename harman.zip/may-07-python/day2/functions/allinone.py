def allinone(n, **k):
	print k
	print n


l = [1,2,3,4,5]
d = {'name': 'root', 'home':'/home', 'no':12344}
t = (1,2,3,4,5)
allinone(2, **d)
