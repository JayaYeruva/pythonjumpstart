#!/bin/env python 

n = 10

def testit():
   global n
   n = 100
   print n

testit();
print n
