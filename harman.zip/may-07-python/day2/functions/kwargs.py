def kwargs(**kw):
    for k in kw.keys():
	print "%s : " % (k), kw[k]

kwargs(name='nancy', age=35, gender='female')
kwargs(distro='fedora', platform='linux2', version='3.0.18')
