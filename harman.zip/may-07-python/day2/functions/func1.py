#!/bin/env python

def pow(x,n=0):
   return x ** n

print pow(2,3)
print pow(2)


