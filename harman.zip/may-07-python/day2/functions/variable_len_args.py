#!/bin/env python 

def var_len(*arg):
    print arg

var_len(1,2,3,4)
var_len('peter', 'jaclson')
var_len('patric', 'manager', 'sales', 45000, 3434)

def sum_all(*num):
   sum = 0
   for n in num:
      sum+= n
   return 0

#print sum_all(1)
#print sum_all(1,2,3,4,5)
#print sum_all(1,2,3,4,5,6,7,8,9,10)

def testit(n, *a,):
	print n, "\n", a

testit([2,2,3,4,5], 'peter', 'male', 45)
testit('ny', 'peter', 'male', 45)






