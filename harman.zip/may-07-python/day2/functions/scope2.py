#!/bin/env python 

def outter(x, y):
    def inner(x):
        return x **y
    return inner(x)

print outter(2,3) 
