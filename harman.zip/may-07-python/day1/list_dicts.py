#!/bin/env python
fp = open('/etc/passwd')
user_list = []
for line in fp:
    temp =  line.split(':');
    t_d = { 'user' : temp[0], 
	  'passwd' : temp[1],
	  'uid' : temp[2],
	  'gid' : temp[3],
	  'geckos' : temp[4],
	  'home' : temp[5],
	  'shell' : temp[6],
	}
    user_list.append(t_d)
#print user_list[0]
#print user_list[0]['user']
#print user_list[0]['home']
#print user_list[0]['shell']

for user in user_list:
    print "%s\t%s" % (user['user'], user['home'])





fp.close()
