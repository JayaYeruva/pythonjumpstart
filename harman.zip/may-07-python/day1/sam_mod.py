#!/bin/env python 
 """
    a sample module 
 """

version = '1.0.1'

class Demo:
    """
	a dummy class
    """
    pass


def funcy():
    """ 
	a empty function definition
    """
    pass
