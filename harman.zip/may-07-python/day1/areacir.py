#!/bin/env python 

import math
r = input('Enter the radius :')
area = math.pi * r  * r;
print "Area : %.5f" % area
