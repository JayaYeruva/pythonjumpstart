#!/bin/env python 

name = raw_input('Enter the name :')
age = input('Enter the age : ');
gender = raw_input('Enter the gender :')
print "Name :" + name
print "Age :" + str(age)
print "Gender :" + gender
