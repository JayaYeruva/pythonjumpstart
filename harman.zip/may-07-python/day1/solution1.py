#!/bin/env python 

fp = open('emp.dat')
gender = {}
dept = []
for line in fp:
    user_g  = line.split(',')[1]
    user_d  = line.split(',')[3]
    if gender.has_key(user_g):
        gender[user_g] += 1
    else:
	gender[user_g] = 1

    if user_d not in dept:
	dept.append(user_d)

for key in gender.keys():
    print "%s : %d" % (key, gender[key])

print "list of all depts "
print "\n".join(dept)
