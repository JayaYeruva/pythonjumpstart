#!/bin/env python

fp = open('/etc/passwd')
name_list = []
for line in fp:
    #temp = line.split(':')
    #name_list.append( temp[0] )
    name = line.split(':')[0]
    name_list.append(name)

name_list.sort()

for name in name_list:
    print name.upper()
fp.close()
