import sys

import compiler
compiler.compileFile(sys.argv[1])
