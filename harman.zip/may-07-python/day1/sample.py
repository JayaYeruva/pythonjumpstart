#!/bin/env python 

#  sha bang or she bang 
#  comments in python 

#  this is a simple sample python script
import sys
i = 1
while(i<=10):
    if(i == 5):
        break;  
    print "Bangalore pipers" + sys.platform,
    i += 1

