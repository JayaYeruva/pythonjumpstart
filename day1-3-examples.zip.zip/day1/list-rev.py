#!/usr/bin/env python

s = 'root:x:0:0:root:/root:/bin/bash'
l = s.split(':')
print l
l.reverse()
print l
