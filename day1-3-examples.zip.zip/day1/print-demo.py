#!/usr/bin/env python

print 'amanda',
print 'kimberly',
print 'nancy',
print 'oliver',
print 'rose',
print 'brownlow'

