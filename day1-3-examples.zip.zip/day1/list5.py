#!/usr/bin/env python

l = [1, 'one', 1.0]
l.insert(0, 'rossum')

del(l[-2])

print l; print

