#!/usr/bin/env python

l = ['pam', 1, 'emy', 10, 'tim', 3, \
		'tom', 'sam', 'amanda', 4, 2 ]
l.sort(reverse=True)
print l
