#!/usr/bin/env python

s = "the\npython's\tstring"
print s

s = r"the\npython's\tstring"
print s
#print s.encode('hex')

