#!/usr/bin/env python

name = 'spring people'
city = 'bangalore'

print "Name :", name
print "City :", city

