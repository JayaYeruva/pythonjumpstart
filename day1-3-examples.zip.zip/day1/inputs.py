#!/usr/bin/env python
# demo on the inputs
name = raw_input('Enter the name :')
city = raw_input('Enter the city :')
zipcode = int( raw_input('Enter the zip :') )
'''
print "Name :", name
print "City :", city
'''
#''' doc string 
print zipcode
print type(zipcode)

