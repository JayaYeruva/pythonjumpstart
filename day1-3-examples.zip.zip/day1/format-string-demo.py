#!/usr/bin/env python

print "%s|%d|%s|" % ('james', 4, 'male')
print "%12s|%4d|%8s|" % ('james', 4, 'male')
print "%12s|%4d|%8s|" % ('james', 4, 'male')
print "%12s|%4d|%8s|" % ('james', 4, 'male')
print "%12s|%4d|%8s|" % ('james', 4, 'male')
print "%-12s|%-4d|%-8s|" % ('james', 4, 'male')
print "%-12s|%-4d|%-8s|" % ('james', 4, 'male')
print "%-12s|%-4d|%-8s|" % ('james', 4, 'male')
print "%-12s|%-4d|%-8s|" % ('james abe cameron', 4, 'male')
