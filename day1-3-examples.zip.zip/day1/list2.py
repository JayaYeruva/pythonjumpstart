#!/usr/bin/env python

l = [1, 'one', 1.0]
print l
print type(l)
print len(l)
