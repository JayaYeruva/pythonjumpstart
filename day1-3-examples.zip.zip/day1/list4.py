#!/usr/bin/env python

l = [1, 'one', 1.0]
l.append('pypi')
l.append('cpan')
l.insert(0, 'rossum')

print l; print

