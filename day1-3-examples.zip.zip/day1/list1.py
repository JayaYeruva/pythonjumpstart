#!/usr/bin/env python

l = []
print l
print type(l)
print len(l)
