#!/usr/bin/env python

info = {}
print info
print len(info)
print type(info)
