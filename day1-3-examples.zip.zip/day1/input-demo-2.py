#!/usr/bin/env python

value = input('enter the string :')
print value
print value(2,3)
