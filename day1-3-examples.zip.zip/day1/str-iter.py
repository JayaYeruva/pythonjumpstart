#!/usr/bin/env python

s = 'pypi'
i = 1
for char \
	in s:
    print char * i
    i += 1

print 'block ends here'

  
