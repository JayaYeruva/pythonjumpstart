#!/usr/bin/env python

l = range(1, 6)
l[-3] = 'three'
print l

print l[0]
print l[1] 
print l[-1]
print l[-2]

