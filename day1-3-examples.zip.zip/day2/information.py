#!/usr/bin/env python
from pprint import pprint 
info = { 'name' : 'cameron', 
	 'place' : 'hollywood', 
	 'occupation' : ['director', 'producer', 'writer'], 
	 'interest' : {'cook' : ['indian', 'chinese'], 
			'reads' : ['sci-fi', 'fiction'],
			'others' : 'sleep' }
	}

pprint(info)
