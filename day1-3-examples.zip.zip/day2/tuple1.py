#!/usr/bin/env python

t = ()
print t
print type(t)
print len(t)
