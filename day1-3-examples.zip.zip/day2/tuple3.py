#!/usr/bin/env python

t = ('perl', 'v5.18', 'larry wall', 102.2)
print t[-1]
print t[-2]; print 

print t[1:-1]; print 

for item in t:
     print item

print

print t + t; print
print t * 2
