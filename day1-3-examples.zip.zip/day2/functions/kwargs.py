#!/usr/bin/env python

def demo(**args):
    print args

demo()
demo(name='larry', lang='perl', version='5.18', release='parrot')

