#!/usr/bin/env python

t = ('perl', 'v5.18', 'larry wall', 102.2)
print t
print type(t)
print len(t)
