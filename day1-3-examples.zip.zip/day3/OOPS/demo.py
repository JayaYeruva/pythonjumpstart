#!/usr/bin/env python

class Demo(object):
    pass

if __name__ == '__main__':
    d = Demo()
    print Demo
    print type(Demo)
    print d
    print type(d)
    
