#!/usr/bin/env python
#from sys import path
#path.insert(0, 'lib')

import dummy

print dummy.name
print dummy.version

print dummy.get_output('ls -li')
