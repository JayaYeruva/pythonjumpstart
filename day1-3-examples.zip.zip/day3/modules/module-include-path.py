#!/usr/bin/env python
from pprint import pprint
from sys import path
for item in path:
   print item
#pprint(path)
